import type { Request, Response } from "express";
import OpenAI from "openai";
import jwt from "jsonwebtoken";
import { storage } from "./storage";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const ONBOARDING_SYSTEM_PROMPT = `You are JACE — an interactive voice + chat onboarding guide for JACE settlements.

GOAL
- Help an investor routed from BondAI complete their remaining onboarding steps inside JACE.
- Stay focused on: KYC/document uploads, agreement acknowledgments, settlement preferences, timeline, and next actions.
- Be calm, concise, and step-by-step. Ask at most one clarifying question at a time.
- If the user says they do NOT want voice guidance, respond in text and suggest they can use the on-page chat; do not pressure.

VOICE STYLE
- Speak in clear British English (UK). Friendly, professional, 30-ish tone.
- Keep spoken replies short (2-5 sentences) and offer to continue.

SAFETY
- Do not request highly sensitive data beyond what is standard for onboarding (e.g., do not ask for full SSN, passwords, bank login). If needed, advise the user to use the secure upload components.
- Do not give legal, tax, or investment advice. You may explain what documents are commonly required and why.

JACE SETTLEMENT ONBOARDING CHECKLIST (canonical)
1) Confirm investor details (name, email, phone)
2) Upload KYC docs (gov ID + proof of address; entity docs if applicable)
3) Review & sign required agreements / disclosures
4) Configure settlement preferences (funding method, payout instructions, escrow / compliance notes)
5) Final review + confirmation (status: Ready)

When possible, guide the user to the next step and confirm completion.`;

type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

type OnboardingTokenPayload = {
  investorId?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  bondaiInvestorId?: number;
  [k: string]: any;
};

function safeDecodeToken(token?: string | null): OnboardingTokenPayload | null {
  if (!token) return null;
  const secret = process.env.JACE_ONBOARDING_JWT_SECRET;
  try {
    if (secret) {
      return jwt.verify(token, secret) as any;
    }
    // If no secret configured, allow unsigned decode for dev/demo.
    return jwt.decode(token) as any;
  } catch {
    return null;
  }
}

async function buildInvestorContext(tokenPayload: OnboardingTokenPayload | null) {
  if (!tokenPayload?.email) return null;

  const ownerUserId = process.env.ONBOARDING_DEFAULT_OWNER_USER_ID;
  if (!ownerUserId) return { warning: "ONBOARDING_DEFAULT_OWNER_USER_ID not configured" };

  // Best-effort: find an existing investor by email. If none, create.
  const existing = await storage.getInvestors(ownerUserId);
  const match = existing.find((i) => i.email?.toLowerCase() === tokenPayload.email!.toLowerCase());

  if (match) {
    return {
      investor: {
        id: match.id,
        firstName: match.firstName,
        lastName: match.lastName,
        email: match.email,
        pipelineStage: match.pipelineStage,
      },
    };
  }

  const created = await storage.createInvestor(ownerUserId, {
    firstName: tokenPayload.firstName || "",
    lastName: tokenPayload.lastName || "",
    email: tokenPayload.email,
    phone: (tokenPayload as any).phone || "",
    company: (tokenPayload as any).company || "",
    status: "active",
    pipelineStage: "onboarding",
    notes: `Created via public onboarding${tokenPayload.bondaiInvestorId ? ` (BondAI ID: ${tokenPayload.bondaiInvestorId})` : ""}`,
  } as any);

  return {
    investor: {
      id: created.id,
      firstName: created.firstName,
      lastName: created.lastName,
      email: created.email,
      pipelineStage: created.pipelineStage,
    },
  };
}

export async function handleOnboardingBootstrap(req: Request, res: Response) {
  try {
    const token = typeof req.query.token === "string" ? req.query.token : undefined;
    const payload = safeDecodeToken(token);
    const ctx = await buildInvestorContext(payload);

    const greeting = payload?.firstName
      ? `Welcome, ${payload.firstName}. I'm JACE — your voice guide for settlements onboarding.`
      : "Welcome. I'm JACE — your voice guide for settlements onboarding.";

    res.json({
      investor: (ctx as any)?.investor,
      greeting,
    });
  } catch (e) {
    console.error("onboarding bootstrap error", e);
    res.status(500).json({ error: "Failed to initialize onboarding." });
  }
}

export async function handleOnboardingChat(req: Request, res: Response) {
  try {
    const { message, history = [], token, context } = req.body || {};

    if (!message) return res.status(400).json({ error: "Message is required" });

    const payload = safeDecodeToken(token);
    const investorCtx = await buildInvestorContext(payload);

    // Build messages array with system prompt + optional investor summary.
    const messages: ChatMessage[] = [{ role: "system", content: ONBOARDING_SYSTEM_PROMPT }];

    if ((investorCtx as any)?.investor) {
      const i = (investorCtx as any).investor;
      messages.push({
        role: "system",
        content: `Investor context (read-only): name=${i.firstName} ${i.lastName}; email=${i.email}; pipelineStage=${i.pipelineStage}; investorId=${i.id}.`,
      });
    }

    if (context) {
      // Lightweight hints from the UI.
      messages.push({ role: "system", content: `UI context: ${JSON.stringify(context).slice(0, 1200)}` });
    }

    for (const m of history) {
      if (!m?.role || !m?.content) continue;
      if (m.role !== "user" && m.role !== "assistant") continue;
      messages.push({ role: m.role, content: m.content });
    }

    messages.push({ role: "user", content: message });

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const stream = await openai.chat.completions.create({
      model: "gpt-4.1",
      messages,
      stream: true,
      max_completion_tokens: 1200,
    });

    let fullResponse = "";

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || "";
      if (content) {
        fullResponse += content;
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }

    res.write(`data: ${JSON.stringify({ done: true, fullResponse })}\n\n`);
    res.end();
  } catch (error) {
    console.error("Error in onboarding chat:", error);
    if (res.headersSent) {
      res.write(`data: ${JSON.stringify({ error: "Failed to get response" })}\n\n`);
      res.end();
    } else {
      res.status(500).json({ error: "Failed to process onboarding chat" });
    }
  }
}
