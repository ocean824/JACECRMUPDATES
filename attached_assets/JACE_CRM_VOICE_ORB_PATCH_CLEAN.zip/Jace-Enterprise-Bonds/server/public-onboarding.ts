import type { Express } from "express";
import { handleOnboardingBootstrap, handleOnboardingChat } from "./onboarding-assistant";

export function registerPublicOnboardingRoutes(app: Express) {
  // Bootstrap investor context for the public onboarding page.
  app.get("/api/public/onboarding/bootstrap", handleOnboardingBootstrap);

  // Streaming SSE chat endpoint (used by voice orb + text chat fallback).
  app.post("/api/public/onboarding/help-chat", handleOnboardingChat);
}
