import { useEffect, useMemo, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { X, MessageCircle, Send } from "lucide-react";
import { streamSSE } from "./sse";

type ChatMsg = { role: "user" | "assistant"; content: string };

export function PublicHelpChat({
  onboardingToken,
  investorContext,
}: {
  onboardingToken?: string | null;
  investorContext?: Record<string, any>;
}) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMsg[]>([
    {
      role: "assistant",
      content:
        "Hi — I'm JACE. I can guide you through investor onboarding and settlement setup. Ask me anything, or say 'next' to continue step-by-step.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages.length]);

  const history = useMemo(
    () =>
      messages
        .filter((m) => m.role !== "assistant" || m.content.trim())
        .slice(-12),
    [messages],
  );

  const send = async () => {
    const text = input.trim();
    if (!text || isLoading) return;

    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    setIsLoading(true);

    const controller = new AbortController();
    let assistant = "";

    try {
      await streamSSE(
        "/api/public/onboarding/help-chat",
        {
          message: text,
          history,
          token: onboardingToken,
          context: investorContext,
        },
        (evt) => {
          if (evt?.content) {
            assistant += String(evt.content);
            // Render streaming content as a single assistant bubble.
            setMessages((prev) => {
              const next = [...prev];
              const last = next[next.length - 1];
              if (last?.role === "assistant" && (last as any).__streaming) {
                next[next.length - 1] = { role: "assistant", content: assistant } as any;
                (next[next.length - 1] as any).__streaming = true;
              } else {
                const msg: any = { role: "assistant", content: assistant };
                msg.__streaming = true;
                next.push(msg);
              }
              return next as any;
            });
          }
          if (evt?.done) {
            setMessages((prev) => {
              const next = [...prev];
              const last = next[next.length - 1] as any;
              if (last?.role === "assistant") {
                delete last.__streaming;
              }
              return next;
            });
          }
        },
        controller.signal,
      );
    } catch (e: any) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "Sorry — I couldn't reach the onboarding assistant. Please try again, or use the voice orb.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 rounded-full shadow-lg"
          size="icon"
          variant="default"
          data-testid="public-chat-open"
        >
          <MessageCircle className="h-5 w-5" />
        </Button>
      )}

      {isOpen && (
        <Card className="fixed bottom-6 right-6 z-50 w-[360px] max-w-[calc(100vw-48px)] shadow-xl border border-border">
          <div className="flex items-center justify-between p-4 border-b">
            <div>
              <div className="font-semibold">Onboarding Chat</div>
              <div className="text-xs text-muted-foreground">Text-only fallback</div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <ScrollArea className="h-[340px] p-4">
            <div className="space-y-3">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg px-3 py-2 text-sm whitespace-pre-wrap ${
                      m.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-muted"
                    }`}
                  >
                    {m.content}
                  </div>
                </div>
              ))}
              <div ref={scrollRef} />
            </div>
          </ScrollArea>

          <div className="p-3 border-t flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a question..."
              onKeyDown={(e) => {
                if (e.key === "Enter") send();
              }}
              disabled={isLoading}
            />
            <Button onClick={send} disabled={isLoading || !input.trim()} size="icon">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      )}
    </>
  );
}
