import { useEffect, useMemo, useState } from "react";
import { canBrowserSpeak, pickBritishFemaleVoice } from "./voiceOutput";

export function useSpeechSynthesisVoice() {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);

  useEffect(() => {
    if (!canBrowserSpeak()) return;

    const load = () => {
      const v = window.speechSynthesis.getVoices();
      if (v?.length) setVoices(v);
    };

    load();
    window.speechSynthesis.onvoiceschanged = load;

    return () => {
      // Cleanup handler
      try {
        window.speechSynthesis.onvoiceschanged = null;
      } catch {
        // ignore
      }
    };
  }, []);

  const voice = useMemo(() => pickBritishFemaleVoice(voices), [voices]);

  return { voice, voicesReady: voices.length > 0 };
}
