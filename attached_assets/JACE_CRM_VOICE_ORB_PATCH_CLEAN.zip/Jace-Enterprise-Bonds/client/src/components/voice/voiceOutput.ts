export type VoiceEngine = "browser_tts";

function normalizeName(s: string) {
  return s.toLowerCase().replace(/\s+/g, " ").trim();
}

export function pickBritishFemaleVoice(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | undefined {
  // Many platforms don't expose gender. We best-effort match common UK female voice names.
  const preferredNameHints = [
    "google uk english female",
    "microsoft sonia",
    "microsoft libby",
    "microsoft mia",
    "serena",
    "rachel",
    "kate",
    "fiona",
    "amy",
  ];

  const ukVoices = voices.filter((v) => v.lang?.toLowerCase().startsWith("en-gb"));
  if (ukVoices.length === 0) return undefined;

  for (const hint of preferredNameHints) {
    const found = ukVoices.find((v) => normalizeName(v.name).includes(hint));
    if (found) return found;
  }

  // Fallback: first UK voice.
  return ukVoices[0];
}

export function canBrowserSpeak() {
  return typeof window !== "undefined" && "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;
}

export function speak(text: string, opts?: { voice?: SpeechSynthesisVoice; rate?: number; pitch?: number; volume?: number }) {
  if (!canBrowserSpeak()) return;

  // Cancel any ongoing speech so we don't stack.
  window.speechSynthesis.cancel();

  const u = new SpeechSynthesisUtterance(text);
  u.lang = "en-GB";
  if (opts?.voice) u.voice = opts.voice;
  u.rate = opts?.rate ?? 1.0;
  u.pitch = opts?.pitch ?? 1.0;
  u.volume = opts?.volume ?? 1.0;

  window.speechSynthesis.speak(u);
}

export function stopSpeaking() {
  if (!canBrowserSpeak()) return;
  window.speechSynthesis.cancel();
}
