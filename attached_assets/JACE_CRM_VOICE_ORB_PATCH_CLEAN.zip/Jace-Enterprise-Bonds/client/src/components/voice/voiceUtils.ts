export type VoicePreference = {
  engine: "browser_tts";
  voiceName?: string;
  lang?: string;
  rate?: number;
  pitch?: number;
};

const DEFAULT_LANG = "en-GB";

export function getAvailableVoices(): SpeechSynthesisVoice[] {
  if (typeof window === "undefined") return [];
  return window.speechSynthesis?.getVoices?.() ?? [];
}

function scoreVoice(v: SpeechSynthesisVoice): number {
  const name = (v.name || "").toLowerCase();
  const lang = (v.lang || "").toLowerCase();

  let score = 0;

  // Prefer en-GB voices.
  if (lang.startsWith("en-gb")) score += 50;
  if (lang.includes("united kingdom") || lang.includes("gb")) score += 20;

  // Prefer common high quality female UK voices when available.
  // (Different OSes expose different names, so we use fuzzy matching.)
  const prefer = [
    "google uk english female",
    "microsoft sonia",
    "microsoft libby",
    "microsoft mia",
    "microsoft hazel",
    "microsoft ryan", // sometimes male, but UK
    "serena", // macOS UK
    "kate", // macOS UK
    "english (united kingdom)",
    "british",
    "uk",
    "london",
  ];

  for (const p of prefer) {
    if (name.includes(p)) score += 15;
  }

  // Deprioritize robotic/low quality voices.
  const avoid = ["compact", "espeak", "robot", "alex", "fred"]; // fred/alex are US-ish
  for (const a of avoid) {
    if (name.includes(a)) score -= 10;
  }

  if (v.default) score += 5;

  return score;
}

export function pickBritishEnglishVoice(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | undefined {
  if (!voices.length) return undefined;

  const sorted = [...voices].sort((a, b) => scoreVoice(b) - scoreVoice(a));
  return sorted[0];
}

export function stopSpeaking() {
  if (typeof window === "undefined") return;
  try {
    window.speechSynthesis?.cancel?.();
  } catch {
    // ignore
  }
}

export async function speak(text: string, pref?: Partial<VoicePreference>) {
  if (typeof window === "undefined") return;
  if (!text.trim()) return;

  // Ensure voices are hydrated.
  const ensureVoices = async () => {
    const initial = getAvailableVoices();
    if (initial.length) return initial;

    // Some browsers async-load voices.
    await new Promise<void>((resolve) => {
      const timeout = setTimeout(() => resolve(), 250);
      window.speechSynthesis.onvoiceschanged = () => {
        clearTimeout(timeout);
        resolve();
      };
    });

    return getAvailableVoices();
  };

  const voices = await ensureVoices();
  const chosen = pickBritishEnglishVoice(voices);

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = pref?.lang ?? DEFAULT_LANG;
  utterance.rate = pref?.rate ?? 1;
  utterance.pitch = pref?.pitch ?? 1;
  if (pref?.voiceName) {
    utterance.voice = voices.find((v) => v.name === pref.voiceName) ?? chosen;
  } else {
    utterance.voice = chosen;
  }

  // IMPORTANT: Cancel any existing speech so the agent feels responsive.
  stopSpeaking();
  window.speechSynthesis.speak(utterance);

  return new Promise<void>((resolve, reject) => {
    utterance.onend = () => resolve();
    utterance.onerror = (e) => reject(e);
  });
}
