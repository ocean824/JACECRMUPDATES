import { useEffect, useRef } from "react";

/**
 * Calls `onFirstGesture` exactly once after the first *user* interaction.
 * We listen to multiple events so it works on desktop + mobile.
 */
export function useUserGesture(onFirstGesture: () => void, enabled = true) {
  const fired = useRef(false);

  useEffect(() => {
    if (!enabled) return;

    const fireOnce = () => {
      if (fired.current) return;
      fired.current = true;
      onFirstGesture();
      cleanup();
    };

    // Use passive listeners to avoid scroll jank.
    const opts: AddEventListenerOptions = { passive: true };

    const cleanup = () => {
      window.removeEventListener("pointerdown", fireOnce);
      window.removeEventListener("pointermove", fireOnce);
      window.removeEventListener("touchstart", fireOnce);
      window.removeEventListener("keydown", fireOnce);
      window.removeEventListener("scroll", fireOnce);
    };

    window.addEventListener("pointerdown", fireOnce, opts);
    window.addEventListener("pointermove", fireOnce, opts);
    window.addEventListener("touchstart", fireOnce, opts);
    window.addEventListener("keydown", fireOnce, opts);
    window.addEventListener("scroll", fireOnce, opts);

    return cleanup;
  }, [enabled, onFirstGesture]);
}
