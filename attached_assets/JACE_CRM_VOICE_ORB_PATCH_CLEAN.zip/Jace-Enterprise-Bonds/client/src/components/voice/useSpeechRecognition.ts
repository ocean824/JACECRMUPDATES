import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type SpeechRecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: any) => void) | null;
  onerror: ((event: any) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};

export type SpeechInputState = {
  isSupported: boolean;
  isListening: boolean;
  transcript: string;
  interim: string;
  error?: string;
  start: () => void;
  stop: () => void;
  reset: () => void;
};

export function useSpeechRecognition(lang = "en-GB"): SpeechInputState {
  const RecognitionCtor = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  const isSupported = !!RecognitionCtor;

  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [interim, setInterim] = useState("");
  const [error, setError] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (!isSupported) return;

    const rec: SpeechRecognitionLike = new RecognitionCtor();
    rec.lang = lang;
    rec.continuous = false;
    rec.interimResults = true;

    rec.onresult = (event: any) => {
      let finalText = "";
      let interimText = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        if (res.isFinal) finalText += res[0]?.transcript ?? "";
        else interimText += res[0]?.transcript ?? "";
      }
      if (finalText) {
        setTranscript((prev) => (prev ? `${prev} ${finalText}` : finalText).trim());
        setInterim("");
      } else {
        setInterim(interimText);
      }
    };

    rec.onerror = (event: any) => {
      setError(event?.error || "speech_recognition_error");
      setIsListening(false);
    };

    rec.onend = () => {
      setIsListening(false);
      setInterim("");
    };

    recRef.current = rec;

    return () => {
      try {
        rec.stop();
      } catch {
        // ignore
      }
      recRef.current = null;
    };
  }, [RecognitionCtor, isSupported, lang]);

  const start = useCallback(() => {
    if (!isSupported || !recRef.current) return;
    setError(undefined);
    setTranscript("");
    setInterim("");
    setIsListening(true);
    try {
      recRef.current.start();
    } catch (e: any) {
      setIsListening(false);
      setError(e?.message || "speech_start_failed");
    }
  }, [isSupported]);

  const stop = useCallback(() => {
    if (!isSupported || !recRef.current) return;
    try {
      recRef.current.stop();
    } catch {
      // ignore
    }
  }, [isSupported]);

  const reset = useCallback(() => {
    setTranscript("");
    setInterim("");
    setError(undefined);
  }, []);

  return useMemo(
    () => ({
      isSupported,
      isListening,
      transcript,
      interim,
      error,
      start,
      stop,
      reset,
    }),
    [error, interim, isListening, isSupported, reset, start, stop, transcript],
  );
}
