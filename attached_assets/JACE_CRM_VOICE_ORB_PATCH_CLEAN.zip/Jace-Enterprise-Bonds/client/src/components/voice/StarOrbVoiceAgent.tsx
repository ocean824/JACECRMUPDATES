import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { Mic, MicOff, X, MessageCircle } from "lucide-react";
import { useUserGesture } from "./useUserGesture";
import { speak, stopSpeaking } from "./voiceUtils";
import { useSpeechRecognition } from "./useSpeechRecognition";
import { streamSSE } from "./sse";

type ChatMsg = { role: "user" | "assistant"; content: string };

function getLS(key: string) {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function setLS(key: string, val: string) {
  try {
    localStorage.setItem(key, val);
  } catch {
    // ignore
  }
}

export function StarOrbVoiceAgent({
  mode,
  onboardingToken,
  investorContext,
  onOpenTextChat,
}: {
  mode: "crm" | "onboarding";
  onboardingToken?: string | null;
  investorContext?: Record<string, any>;
  onOpenTextChat?: () => void;
}) {
  const defaultEnabled = mode === "onboarding";
  const [enabled, setEnabled] = useState<boolean>(() => {
    const raw = getLS("jace_voice_enabled");
    if (raw === "0") return false;
    if (raw === "1") return true;
    return defaultEnabled;
  });
  const [panelOpen, setPanelOpen] = useState(false);
  const [status, setStatus] = useState<"idle" | "listening" | "thinking" | "speaking">("idle");
  const [lastAssistant, setLastAssistant] = useState<string>(
    mode === "onboarding"
      ? "Tap the orb to ask a question, or say something like: 'What do I need to upload?'"
      : "Need help? Tap to ask me anything about JACE CRM.",
  );

  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const greetedRef = useRef(false);
  const speech = useSpeechRecognition("en-GB");

  // Pre-warm voices ASAP so the first utterance is fast.
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      window.speechSynthesis?.getVoices?.();
    } catch {
      // ignore
    }
  }, []);

  const setEnabledPersist = useCallback(
    (next: boolean) => {
      setEnabled(next);
      setLS("jace_voice_enabled", next ? "1" : "0");
      if (!next) {
        stopSpeaking();
        setStatus("idle");
      }
    },
    [],
  );

  const endpoint = mode === "onboarding" ? "/api/public/onboarding/help-chat" : "/api/help-chat";

  const history = useMemo(() => messages.slice(-12), [messages]);

  const sendToAssistant = useCallback(
    async (userText: string) => {
      if (!userText.trim()) return;

      setMessages((prev) => [...prev, { role: "user", content: userText }]);
      setStatus("thinking");

      let assistant = "";

      try {
        await streamSSE(
          endpoint,
          mode === "onboarding"
            ? { message: userText, history, token: onboardingToken, context: investorContext }
            : { message: userText, history },
          (evt) => {
            if (evt?.content) {
              assistant += String(evt.content);
              setLastAssistant(assistant);
            }
            if (evt?.done) {
              setLastAssistant(evt.fullResponse || assistant);
            }
          },
        );

        const final = assistant.trim() || lastAssistant;
        if (final) {
          setMessages((prev) => [...prev, { role: "assistant", content: final }]);
        }

        if (enabled && final) {
          setStatus("speaking");
          await speak(final, { lang: "en-GB" }).catch(() => undefined);
        }
      } catch (e) {
        setLastAssistant(
          "Sorry — I couldn't reach the assistant right now. Please try again, or use the text chat.",
        );
      } finally {
        setStatus("idle");
      }
    },
    [enabled, endpoint, history, investorContext, lastAssistant, mode, onboardingToken],
  );

  // Auto-greet on the first user interaction (only if voice is enabled and onboarding mode).
  useUserGesture(
    () => {
      if (mode !== "onboarding") return;
      if (!enabled) return;
      if (greetedRef.current) return;
      greetedRef.current = true;

      const name = investorContext?.firstName || investorContext?.name || "";
      const greeting = name
        ? `Welcome, ${name}. I'm JACE — your voice guide for settlements onboarding. If you'd like, I can walk you step by step.`
        : "Welcome. I'm JACE — your voice guide for settlements onboarding. If you'd like, I can walk you step by step.";

      // Try to speak as quickly as possible.
      setStatus("speaking");
      void speak(greeting, { lang: "en-GB" })
        .catch(() => undefined)
        .finally(() => setStatus("idle"));
    },
    true,
  );

  // When speech recognition produces a final transcript, send it.
  useEffect(() => {
    if (!speech.transcript) return;
    if (status === "thinking") return;

    const text = speech.transcript.trim();
    if (!text) return;

    speech.reset();
    void sendToAssistant(text);
  }, [speech.transcript]);

  const toggleListening = useCallback(() => {
    if (!enabled) {
      setPanelOpen(true);
      return;
    }

    if (!speech.isSupported) {
      setLastAssistant(
        "Voice input isn't supported in this browser. Use the text chat button in the panel.",
      );
      setPanelOpen(true);
      return;
    }

    if (speech.isListening) {
      speech.stop();
      setStatus("idle");
    } else {
      setStatus("listening");
      speech.start();
    }
  }, [enabled, speech]);

  return (
    <>
      {/* Orb */}
      <button
        type="button"
        onClick={() => (panelOpen ? toggleListening() : setPanelOpen(true))}
        className={cn(
          "fixed bottom-6 left-6 z-50 select-none",
          "focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2",
        )}
        aria-label="Open voice assistant"
        data-testid="voice-orb"
      >
        <div
          className={cn(
            "relative h-16 w-16 rounded-full",
            "shadow-lg",
            "bg-gradient-to-br from-indigo-500 via-fuchsia-500 to-amber-400",
            "overflow-hidden",
          )}
        >
          {/* Pulsing glow */}
          <div
            className={cn(
              "absolute inset-0 rounded-full",
              "animate-[pulse_1.6s_ease-in-out_infinite]",
              enabled ? "opacity-60" : "opacity-25",
              "bg-gradient-to-br from-white/25 to-transparent",
            )}
          />

          {/* Star spark */}
          <div className="absolute inset-0 flex items-center justify-center">
            <svg
              width="26"
              height="26"
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className={cn(
                "drop-shadow",
                status === "speaking" ? "animate-[spin_5s_linear_infinite]" : "",
              )}
            >
              <path
                d="M12 2l2.3 6.9H21l-5.6 4.1 2.2 7-5.6-4.1-5.6 4.1 2.2-7L3 8.9h6.7L12 2z"
                fill="rgba(255,255,255,0.92)"
              />
            </svg>
          </div>

          {/* Status dot */}
          <div
            className={cn(
              "absolute -right-1 -top-1 h-4 w-4 rounded-full border-2 border-background",
              status === "listening"
                ? "bg-emerald-500"
                : status === "thinking"
                ? "bg-amber-500"
                : status === "speaking"
                ? "bg-fuchsia-500"
                : enabled
                ? "bg-slate-300"
                : "bg-slate-500",
            )}
          />
        </div>
      </button>

      {/* Panel */}
      {panelOpen && (
        <Card className="fixed bottom-24 left-6 z-50 w-[360px] max-w-[calc(100vw-48px)] shadow-xl border border-border">
          <div className="flex items-center justify-between p-4 border-b">
            <div>
              <div className="font-semibold">JACE Voice Guide</div>
              <div className="text-xs text-muted-foreground">
                British English voice • onboarding + CRM help
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setPanelOpen(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="p-4 space-y-3">
            <div className="text-sm bg-muted rounded-lg p-3 whitespace-pre-wrap">
              {speech.isListening && (speech.interim || "Listening...")}
              {!speech.isListening && lastAssistant}
            </div>

            {speech.error && (
              <div className="text-xs text-destructive">Voice error: {speech.error}</div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Switch
                  checked={enabled}
                  onCheckedChange={setEnabledPersist}
                  id="voice-enabled"
                />
                <label htmlFor="voice-enabled" className="text-sm">
                  Voice guidance
                </label>
              </div>

              <div className="text-xs text-muted-foreground">
                {enabled ? "On" : "Off"}
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={toggleListening}
                className="flex-1"
                variant={speech.isListening ? "secondary" : "default"}
                disabled={!enabled}
              >
                {speech.isListening ? (
                  <>
                    <MicOff className="h-4 w-4 mr-2" />
                    Stop
                  </>
                ) : (
                  <>
                    <Mic className="h-4 w-4 mr-2" />
                    Talk
                  </>
                )}
              </Button>

              <Button
                onClick={() => {
                  stopSpeaking();
                  setStatus("idle");
                }}
                variant="outline"
              >
                Stop
              </Button>
            </div>

            <Button
              variant="ghost"
              className="w-full justify-start"
              onClick={() => {
                setEnabledPersist(false);
                setPanelOpen(false);
                if (onOpenTextChat) onOpenTextChat();
              }}
            >
              <MessageCircle className="h-4 w-4 mr-2" />
              Turn off voice & use text chat
            </Button>

            <div className="text-[11px] text-muted-foreground leading-relaxed">
              Tip: you can say things like “what do I need to upload?”, “next”, or “help me finish onboarding”.
            </div>
          </div>
        </Card>
      )}
    </>
  );
}
