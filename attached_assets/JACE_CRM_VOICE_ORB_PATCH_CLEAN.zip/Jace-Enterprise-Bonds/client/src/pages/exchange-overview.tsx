import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { StarOrbVoiceAgent } from "@/components/voice/StarOrbVoiceAgent";
import { PublicHelpChat } from "@/components/voice/PublicHelpChat";

function getQuery(): Record<string, string> {
  const q = new URLSearchParams(window.location.search);
  const out: Record<string, string> = {};
  q.forEach((v, k) => {
    out[k] = v;
  });
  return out;
}

type BootstrapResponse = {
  investor?: {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    pipelineStage?: string;
  };
  greeting?: string;
  error?: string;
};

export default function ExchangeOverviewPage() {
  const [location, setLocation] = useLocation();
  const query = useMemo(() => getQuery(), [location]);
  const token = query.token || query.onboardingToken || null;
  const onboardingDone = query.onboarding === "done";

  const [bootstrap, setBootstrap] = useState<BootstrapResponse | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      setLoading(true);
      try {
        const url = token
          ? `/api/public/onboarding/bootstrap?token=${encodeURIComponent(token)}`
          : `/api/public/onboarding/bootstrap`;
        const res = await fetch(url);
        const data = (await res.json()) as BootstrapResponse;
        if (!cancelled) setBootstrap(data);
      } catch {
        if (!cancelled) setBootstrap({ error: "Failed to load onboarding session." });
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => {
      cancelled = true;
    };
  }, [token]);

  const investorContext = bootstrap?.investor
    ? {
        investorId: bootstrap.investor.id,
        firstName: bootstrap.investor.firstName,
        lastName: bootstrap.investor.lastName,
        email: bootstrap.investor.email,
        pipelineStage: bootstrap.investor.pipelineStage,
        onboardingDone,
      }
    : {
        onboardingDone,
      };

  return (
    <div className="min-h-screen bg-background">
      <div className="mx-auto max-w-4xl p-6 space-y-6">
        <div className="flex flex-col gap-2">
          <div className="text-3xl font-bold">JACE Settlement Onboarding</div>
          <div className="text-muted-foreground">
            This page is for investors routed from BondAI to complete onboarding for settlements.
          </div>
          {onboardingDone && (
            <div>
              <Badge variant="secondary">BondAI onboarding complete</Badge>
            </div>
          )}
        </div>

        <Card>
          <CardHeader>
            <CardTitle>What happens next</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {loading && <div className="text-sm text-muted-foreground">Loading your session...</div>}
            {bootstrap?.error && (
              <div className="text-sm text-destructive">{bootstrap.error}</div>
            )}

            {bootstrap?.investor && (
              <div className="text-sm">
                Welcome, <span className="font-medium">{bootstrap.investor.firstName}</span>.
                We'll guide you through the remaining steps.
              </div>
            )}

            <Separator />

            <ol className="space-y-3 text-sm">
              <li>
                <span className="font-medium">1) Confirm your details</span> — verify name, email, and contact info.
              </li>
              <li>
                <span className="font-medium">2) Upload KYC documents</span> — ID + proof of address (and any required entity docs).
              </li>
              <li>
                <span className="font-medium">3) Review & sign agreements</span> — settlement disclosures, privacy, and required acknowledgements.
              </li>
              <li>
                <span className="font-medium">4) Settlement preferences</span> — funding + payout details and any escrow instructions.
              </li>
              <li>
                <span className="font-medium">5) Final review</span> — we'll confirm you're “Ready” and notify the JACE team.
              </li>
            </ol>

            <div className="flex flex-wrap gap-2">
              <Button onClick={() => setLocation("/register")}>Create a portal login (optional)</Button>
              <Button variant="outline" onClick={() => setLocation("/")}>Go to homepage</Button>
            </div>

            <div className="text-xs text-muted-foreground leading-relaxed">
              Tip: The pulsing orb will greet you and can answer questions out loud. You can disable voice at any time and use text chat.
            </div>
          </CardContent>
        </Card>

        {/* Voice + Text assistant */}
        <PublicHelpChat onboardingToken={token} investorContext={investorContext} />
        <StarOrbVoiceAgent
          mode="onboarding"
          onboardingToken={token}
          investorContext={investorContext}
          onOpenTextChat={() => {
            // PublicHelpChat has its own open button; nothing required.
          }}
        />
      </div>
    </div>
  );
}
