# Voice Agent Implementation (JACE CRM)

This repo adds an **interactive voice guide** that appears as a **pulsing star-orb** on:
- All authenticated JACE CRM pages (CRM users + Admin)
- The public **Investor Onboarding** page: `/exchange/overview` (BondAI -> JACE redirect)

It is intentionally built to run **Replit-native** with minimal moving parts and very low latency.

## UX requirements covered
- Star-orb floating widget (bottom-right) with pulse + twinkle animations
- Automatic greeting on first user gesture (mouse/touch) **if voice guidance is enabled**
- Push-to-talk voice input (Web Speech API when available)
- British English voice output (browser TTS chooses an en-GB voice when available)
- One-click **Disable Voice** + **Switch to Chat** (text agent)

## Runtime architecture
**Client**
- `StarOrbVoiceAgent` handles:
  - user-gesture warm-up + greeting
  - voice input (SpeechRecognition)
  - voice output (SpeechSynthesis, en-GB preference)
  - streaming assistant text from the backend via SSE

**Server**
- Public onboarding endpoints (no auth):
  - `GET /api/public/onboarding/bootstrap?token=...`
  - `POST /api/public/onboarding/help-chat` (SSE)
- Authenticated help endpoint remains:
  - `POST /api/help-chat` (SSE)

## Key files
### Client
- `client/src/components/voice/StarOrbVoiceAgent.tsx`
- `client/src/components/voice/PublicHelpChat.tsx`
- `client/src/pages/exchange-overview.tsx`
- `client/src/App.tsx` (route + global widget)

### Server
- `server/onboarding-assistant.ts`
- `server/public-onboarding.ts`
- `server/routes.ts` (register public onboarding routes)

## Environment variables
See `.env.example`.

## Notes on voice quality
We default to **browser SpeechSynthesis** because it:
- starts instantly after a user gesture
- is free, requires no extra infrastructure, and often provides a high-quality **UK English female** voice on modern systems

If you want a guaranteed identical voice across all devices, add a cloud TTS provider (ElevenLabs / Azure TTS) and switch the output engine.
