import type { Express } from "express";
import fs from "fs";
import path from "path";
import { z } from "zod";
import { db } from "./db";
import { investors } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import { logAudit, storage } from "./storage";

const ForwardLeadSchema = z.object({
  lead: z
    .object({
      sessionId: z.string().optional(),
      source: z.string().optional(),
      leadType: z.string().optional(),
      fullName: z.string().optional(),
      firstName: z.string().optional(),
      lastName: z.string().optional(),
      email: z.string().email().optional(),
      phone: z.string().optional(),
      company: z.string().optional(),
      notes: z.string().optional(),
      consentToStore: z.boolean().optional(),
      deferToManualEntry: z.boolean().optional(),
    })
    .passthrough(),
  capturedVia: z.string().optional(),
});

function ensureDir(dir: string) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

function appendJsonl(filePath: string, obj: any) {
  ensureDir(path.dirname(filePath));
  fs.appendFileSync(filePath, JSON.stringify(obj) + "\n", "utf8");
}

function setCors(req: any, res: any) {
  const origin = req.headers.origin || "*";
  res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Api-Key");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
}

async function upsertInvestorLead(ownerUserId: string, lead: any) {
  const email = String(lead.email || "").trim().toLowerCase();
  const phone = String(lead.phone || "").trim();
  const firstName = String(lead.firstName || "").trim();
  const lastName = String(lead.lastName || "").trim();

  if (!email && !phone) {
    return { created: false, investor: null as any };
  }

  // Try by email first
  if (email) {
    const existing = await db
      .select()
      .from(investors)
      .where(and(eq(investors.userId, ownerUserId as any), eq(investors.email, email)))
      .limit(1);

    if (existing[0]) {
      const inv = existing[0];
      const updates: any = {};
      if (!String(inv.firstName || "").trim() && firstName) updates.firstName = firstName;
      if (!String(inv.lastName || "").trim() && lastName) updates.lastName = lastName;
      if (!String((inv as any).phone || "").trim() && phone) updates.phone = phone;

      let updated = inv;
      if (Object.keys(updates).length > 0) {
        const rows = await db
          .update(investors)
          .set({ ...updates, updatedAt: new Date() } as any)
          .where(and(eq(investors.id, inv.id), eq(investors.userId, ownerUserId as any)))
          .returning();
        updated = rows[0] || inv;
      }
      return { created: false, investor: updated };
    }
  }

  // Create a new Investor in LEAD stage (minimal required fields)
  const safeEmail = email || `unknown-${Date.now()}@example.invalid`;
  const inv = await storage.createInvestor(ownerUserId, {
    firstName: firstName || "Lead",
    lastName: lastName || "",
    email: safeEmail,
    phone: phone || null,
    pipelineStage: "lead",
    status: "new",
    score: 0,
    tags: lead.company ? [String(lead.company)] : [],
    notes: lead.notes ? String(lead.notes) : null,
  } as any);

  return { created: true, investor: inv };
}

export function registerVoiceLeadRoutes(app: Express) {
  app.options("/api/voice/leads", (req, res) => {
    setCors(req, res);
    return res.status(204).send();
  });

  // Receives lead captures forwarded from the ViralVidFlow voice app.
  // Authorization: Bearer <JACE_VOICE_LEADS_FORWARD_BEARER>
  app.post("/api/voice/leads", async (req, res) => {
    setCors(req, res);
    try {
      const bearer = String(process.env.JACE_VOICE_LEADS_FORWARD_BEARER || "").trim();
      if (bearer) {
        const auth = String(req.headers.authorization || "");
        if (auth !== `Bearer ${bearer}`) {
          return res.status(401).json({ ok: false, message: "unauthorized" });
        }
      }

      const parsed = ForwardLeadSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ ok: false, error: "invalid_body", details: parsed.error.flatten() });
      }

      const lead = parsed.data.lead;
      if (lead.deferToManualEntry) {
        return res.json({ ok: false, skipped: true, reason: "manual_entry" });
      }
      if (!lead.consentToStore) {
        return res.json({ ok: false, skipped: true, reason: "no_consent" });
      }

      const ownerUserId = String(process.env.ONBOARDING_DEFAULT_OWNER_USER_ID || "").trim();
      if (!ownerUserId) {
        // still persist to file so you don't lose the lead
        appendJsonl("./.data/voice-leads.jsonl", { ...parsed.data, receivedAt: new Date().toISOString() });
        return res.status(500).json({ ok: false, message: "ONBOARDING_DEFAULT_OWNER_USER_ID is not set" });
      }

      // Persist to a durable file for redundancy
      appendJsonl("./.data/voice-leads.jsonl", { ...parsed.data, receivedAt: new Date().toISOString() });

      const result = await upsertInvestorLead(ownerUserId, lead);
      await logAudit(ownerUserId, "voice_lead_forward", "investor", result.investor?.id || null, {
        capturedVia: parsed.data.capturedVia || null,
        lead,
        created: result.created,
      });

      return res.json({ ok: true, created: result.created, investor: result.investor });
    } catch (err: any) {
      console.error("/api/voice/leads error:", err);
      // Always persist so you have it even on failure
      try {
        appendJsonl("./.data/voice-leads.jsonl", { body: req.body, error: String(err?.message || err), receivedAt: new Date().toISOString() });
      } catch {
        // ignore
      }
      return res.status(500).json({ ok: false, message: err?.message || "failed" });
    }
  });
}
