import React, { useMemo, useState } from "react";
import { useLocation } from "wouter";

type Props = {
  agentBaseUrl: string;
  /** Show only on these paths (exact match or prefix match). */
  onlyOnPaths?: string[];
  /** Optional title shown above the iframe */
  title?: string;
};

function matchesPath(pathname: string, onlyOnPaths?: string[]) {
  if (!onlyOnPaths || onlyOnPaths.length === 0) return true;
  return onlyOnPaths.some((p) => pathname === p || (p !== "/" && pathname.startsWith(p)));
}

export default function VoiceAssistantWidget({ agentBaseUrl, onlyOnPaths, title }: Props) {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  const pathname = location || window.location.pathname;

  const shouldShow = useMemo(() => matchesPath(pathname, onlyOnPaths), [pathname, onlyOnPaths]);

  const iframeSrc = useMemo(() => {
    const parentOrigin = encodeURIComponent(window.location.origin);
    try {
      const u = new URL(agentBaseUrl);
      // Keep whatever path the operator provided; just add query params.
      u.searchParams.set("embed", "1");
      u.searchParams.set("parent_origin", parentOrigin);
      return u.toString();
    } catch {
      const base = String(agentBaseUrl || "").replace(/\/$/, "");
      return `${base}/?embed=1&parent_origin=${parentOrigin}`;
    }
  }, [agentBaseUrl]);

  if (!agentBaseUrl || !shouldShow) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50">
      {open ? (
        <div className="w-[360px] h-[520px] rounded-2xl shadow-2xl border bg-background overflow-hidden flex flex-col">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <div className="font-medium text-sm">{title ?? "Voice Assistant"}</div>
            <button
              className="text-sm px-2 py-1 rounded-md border hover:bg-accent"
              onClick={() => setOpen(false)}
              aria-label="Close voice assistant"
            >
              Close
            </button>
          </div>
          <iframe
            src={iframeSrc}
            className="flex-1 w-full"
            allow="microphone; autoplay"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
            title="Voice assistant"
          />
        </div>
      ) : null}

      <button
        onClick={() => setOpen((v) => !v)}
        className="mt-3 ml-auto flex items-center justify-center w-14 h-14 rounded-full shadow-lg border bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 text-white"
        aria-label="Open voice assistant"
        title="Open voice assistant"
      >
        <span className="text-xl">🎙️</span>
      </button>
    </div>
  );
}
