import React, { useEffect, useMemo, useState } from "react";

type Props = {
  agentBaseUrl: string;
  /**
   * Show only on these paths (exact or prefix match). If omitted, shows everywhere.
   * Example: ["/", "/external/onboarding"]
   */
  onlyOnPaths?: string[];
  /**
   * Default open state.
   */
  defaultOpen?: boolean;
};

function pathMatches(pathname: string, onlyOnPaths?: string[]) {
  if (!onlyOnPaths || onlyOnPaths.length === 0) return true;
  return onlyOnPaths.some((p) => {
    if (p === pathname) return true;
    if (p !== "/" && pathname.startsWith(p)) return true;
    if (p === "/" && pathname === "/") return true;
    return false;
  });
}

export default function VoiceAssistantWidget({ agentBaseUrl, onlyOnPaths, defaultOpen }: Props) {
  const [open, setOpen] = useState<boolean>(!!defaultOpen);

  const shouldShow = useMemo(() => {
    try {
      return pathMatches(window.location.pathname, onlyOnPaths);
    } catch {
      return true;
    }
  }, [onlyOnPaths]);

  const iframeSrc = useMemo(() => {
    try {
      const u = new URL(agentBaseUrl);
      // keep any path the user provides; default to /agent
      if (u.pathname === "/" || !u.pathname) u.pathname = "/agent";
      u.searchParams.set("embed", "1");
      u.searchParams.set("parent_origin", window.location.origin);
      return u.toString();
    } catch {
      return `${agentBaseUrl.replace(/\/$/, "")}/agent?embed=1`;
    }
  }, [agentBaseUrl]);

  // Close on route changes (best-effort)
  useEffect(() => {
    const onPop = () => setOpen(false);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  if (!agentBaseUrl || !shouldShow) return null;

  return (
    <div
      style={{
        position: "fixed",
        right: 18,
        bottom: 18,
        zIndex: 9999,
        fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
      }}
    >
      {/* Toggle button */}
      <button
        onClick={() => setOpen((v) => !v)}
        style={{
          width: 56,
          height: 56,
          borderRadius: 9999,
          border: "1px solid rgba(255,255,255,0.25)",
          background: "linear-gradient(135deg, rgba(79,70,229,1), rgba(236,72,153,1))",
          color: "white",
          boxShadow: "0 12px 30px rgba(0,0,0,0.25)",
          cursor: "pointer",
        }}
        aria-label={open ? "Close voice assistant" : "Open voice assistant"}
        title={open ? "Close voice assistant" : "Open voice assistant"}
      >
        {/* simple orb glyph */}
        <span style={{ display: "inline-block", transform: open ? "scale(0.9)" : "scale(1)", transition: "transform 120ms" }}>
          🎙️
        </span>
      </button>

      {/* Panel */}
      {open ? (
        <div
          style={{
            width: 360,
            height: 520,
            marginTop: 10,
            borderRadius: 14,
            overflow: "hidden",
            background: "#0b0b10",
            border: "1px solid rgba(255,255,255,0.12)",
            boxShadow: "0 18px 50px rgba(0,0,0,0.35)",
          }}
        >
          <div
            style={{
              padding: "10px 12px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 10,
              background: "rgba(255,255,255,0.06)",
              color: "white",
            }}
          >
            <div style={{ fontSize: 13, opacity: 0.9 }}>Voice assistant</div>
            <button
              onClick={() => setOpen(false)}
              style={{
                border: "none",
                background: "transparent",
                color: "white",
                cursor: "pointer",
                opacity: 0.85,
                fontSize: 16,
              }}
              aria-label="Close voice assistant"
              title="Close"
            >
              ✕
            </button>
          </div>
          <iframe
            src={iframeSrc}
            style={{ width: "100%", height: "100%", border: "none" }}
            allow="microphone; autoplay"
            sandbox="allow-same-origin allow-scripts allow-forms allow-modals allow-popups"
          />
        </div>
      ) : null}
    </div>
  );
}
