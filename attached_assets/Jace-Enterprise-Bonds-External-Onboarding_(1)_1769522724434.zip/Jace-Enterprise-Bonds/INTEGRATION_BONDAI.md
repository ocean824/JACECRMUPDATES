# BondAI ↔ JACE External Investor Onboarding Integration

This JACE app exposes a **public, embeddable onboarding page** that BondAI can open in an iframe overlay.

## 1) Create an onboarding session (BondAI → JACE)

**Request**
- Method: `POST`
- URL: `https://<JACE_REPLIT_HOST>/api/external/onboarding/sessions`
- Header: `x-api-key: <BONDAI_INTEGRATION_API_KEY>`
- Body JSON:
```json
{
  "bondaiInvestorId": "INVESTOR_ID_FROM_BONDAI",
  "fullName": "Jane Doe",
  "email": "jane@example.com",
  "phone": "+1 555-123-4567"
}
```

**Response**
```json
{
  "sessionId": "uuid",
  "investorId": "uuid",
  "expiresAt": "2026-01-27T12:34:56.000Z",
  "onboardingUrl": "https://<JACE_REPLIT_HOST>/external/onboarding?token=..."
}
```

BondAI should open `onboardingUrl` in an **iframe overlay**.

## 2) Embed JACE onboarding in BondAI (recommended UX)

- Create a full-screen modal/overlay on top of the investor dashboard.
- Load the `onboardingUrl` into an `<iframe>`.

### postMessage events (optional but best UX)

JACE sends:
- `type: "JACE_ONBOARDING_COMPLETE"` after successful submission
- `type: "JACE_ONBOARDING_CANCEL"` when user clicks “Back to BondAI”

BondAI should also rely on the **server webhook** (below) as the source of truth.

## 3) Completion webhook (JACE → BondAI)

JACE calls `BONDAI_WEBHOOK_URL` (configured in JACE env).

**Headers**
- `x-api-key: <BONDAI_INTEGRATION_API_KEY>` (if present in env)
- `x-webhook-timestamp: <unix_seconds>` (only if BONDAI_WEBHOOK_SECRET set)
- `x-webhook-signature: <hex_hmac_sha256>` where:
  - signature = HMAC_SHA256(BONDAI_WEBHOOK_SECRET, `${timestamp}.${rawBody}`)

**Body**
```json
{
  "event": "investor_onboarding_completed",
  "bondaiInvestorId": "INVESTOR_ID_FROM_BONDAI",
  "jaceInvestorId": "JACE_INVESTOR_ID",
  "status": "LIVE",
  "completedAt": "2026-01-27T12:34:56.000Z"
}
```

BondAI should then call its existing internal endpoint that marks investor as live:
- `POST /api/investor/jace/onboard` (routes.ts ~3163-3190)
  - sets `isJaceLive: true` and `jaceOnboardedAt: timestamp`

## 4) Security notes

- Embedding is controlled via CSP `frame-ancestors` using `BONDAI_ALLOWED_FRAME_ANCESTORS`.
- All submissions are stored encrypted using `JACE_ENCRYPTION_KEY_BASE64`.
- Timestamp + IP are captured server-side at submission.

## 5) BondAI file locations you shared (for convenience)

- Investor cleared endpoint:
  - `POST /api/investor/jace/onboard` (server/routes.ts ~3163-3190)
- Start Onboarding button:
  - `client/src/pages/investor-overview.tsx` lines ~133-149
- Full onboarding page (BondAI internal):
  - `client/src/pages/investor-jace-onboarding.tsx`
- Status endpoint:
  - `GET /api/investor/jace/status` (routes.ts ~3138-3158)
- Frontend status hook:
  - `client/src/hooks/use-investor-access.ts`

If you want, I can generate the BondAI iframe overlay wrapper page so `/exchange/jace-onboarding` simply loads the JACE onboarding URL.
