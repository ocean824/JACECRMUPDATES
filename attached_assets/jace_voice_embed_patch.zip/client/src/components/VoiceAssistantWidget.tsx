import React, { useEffect, useMemo, useState } from "react";

type Props = {
  /** Public URL of the voice-agent Replit app, e.g. https://your-voice-agent.replit.app */
  agentBaseUrl: string;
  /** Show on these path prefixes only. If omitted, shows on all pages. */
  onlyOnPaths?: string[];
  /** Bottom/right spacing in px */
  offset?: number;
};

function normalizeBase(url: string): string {
  return url.replace(/\/$/, "");
}

export default function VoiceAssistantWidget({
  agentBaseUrl,
  onlyOnPaths,
  offset = 18
}: Props) {
  const base = useMemo(() => normalizeBase(agentBaseUrl), [agentBaseUrl]);

  const [open, setOpen] = useState(false);
  const [enabled, setEnabled] = useState(true);
  const [path, setPath] = useState<string>(() => window.location.pathname);

  useEffect(() => {
    // Track SPA navigation changes (works for history pushState).
    const onChange = () => setPath(window.location.pathname);

    const _push = history.pushState;
    // @ts-expect-error monkey patch
    history.pushState = function (...args) {
      _push.apply(this, args as any);
      onChange();
    };

    window.addEventListener("popstate", onChange);
    return () => {
      // @ts-expect-error restore
      history.pushState = _push;
      window.removeEventListener("popstate", onChange);
    };
  }, []);

  useEffect(() => {
    if (!onlyOnPaths || onlyOnPaths.length === 0) return;
    const ok = onlyOnPaths.some((p) => path.startsWith(p));
    setEnabled(ok);
    if (!ok) setOpen(false);
  }, [onlyOnPaths, path]);

  if (!enabled) return null;

  const src = `${base}/agent?embed=1`;

  return (
    <>
      {/* Floating button */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        style={{
          position: "fixed",
          right: offset,
          bottom: offset,
          zIndex: 9999,
          borderRadius: 999,
          padding: "12px 14px",
          border: "1px solid rgba(0,0,0,0.15)",
          background: "white",
          boxShadow: "0 10px 30px rgba(0,0,0,0.18)",
          cursor: "pointer"
        }}
        aria-label="Open voice assistant"
        title="Voice assistant"
      >
        🎧 Voice Assistant
      </button>

      {/* Modal overlay */}
      {open && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={() => setOpen(false)}
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.45)",
            zIndex: 10000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 16
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "min(980px, 96vw)",
              height: "min(680px, 86vh)",
              background: "white",
              borderRadius: 16,
              overflow: "hidden",
              boxShadow: "0 18px 60px rgba(0,0,0,0.35)",
              display: "flex",
              flexDirection: "column"
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "10px 12px",
                borderBottom: "1px solid rgba(0,0,0,0.08)"
              }}
            >
              <div style={{ fontWeight: 700 }}>Voice Assistant</div>
              <button
                type="button"
                onClick={() => setOpen(false)}
                style={{
                  border: "1px solid rgba(0,0,0,0.15)",
                  background: "white",
                  borderRadius: 10,
                  padding: "6px 10px",
                  cursor: "pointer"
                }}
              >
                Close
              </button>
            </div>

            <iframe
              title="Voice Assistant"
              src={src}
              style={{ width: "100%", height: "100%", border: 0 }}
              // Critical for mic + autoplay in an iframe.
              allow="microphone; autoplay"
            />
          </div>
        </div>
      )}
    </>
  );
}
