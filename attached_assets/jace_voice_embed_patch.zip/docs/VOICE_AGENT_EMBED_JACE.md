# Embed the Voice Agent in JACE CRM (Replit)

You can embed the voice agent **without merging backends** by loading it in an iframe.
This is the fastest path and keeps your agent as a single Replit app.

## 0) You need two Replit apps

1) **Voice Agent app** (the ZIP you already have: `replit_voice_agent_monorepo.zip`) → will host `/agent`.
2) **JACE CRM app** (already running at your `*.replit.app`) → will embed the iframe.

## 1) Deploy the voice agent app

- Create a new Replit → **Node.js**
- Upload `replit_voice_agent_monorepo.zip`
- Add Secrets:
  - `OPENAI_API_KEY`
  - Recommended voice:
    - `TTS_PROVIDER=azure`
    - `AZURE_TTS_KEY=...`
    - `AZURE_TTS_REGION=...`
    - `AZURE_TTS_VOICE_NAME=en-GB-LibbyNeural`
- Press Run

Copy your voice agent public URL:

- It will look like: `https://YOUR-VOICE-AGENT.replit.app`

## 2) Allow the agent to be embedded (CSP frame-ancestors)

In the voice agent app, find your Express setup (usually `apps/api/src/index.ts` or `apps/api/src/server.ts`) and add:

```ts
app.use((req, res, next) => {
  // Allow iframe embedding inside JACE CRM.
  res.setHeader(
    "Content-Security-Policy",
    "frame-ancestors 'self' https://jace-enterprise-crm.replit.app"
  );
  // Allow microphone in same-origin + embedded contexts.
  res.setHeader("Permissions-Policy", "microphone=(self)");
  next();
});
```

(If you already set CSP elsewhere, *append* `frame-ancestors ...` to the existing value.)

## 3) Add the embed widget component to JACE CRM

### 3.1 Create the file

Create this file in the JACE CRM repo:

- `client/src/components/VoiceAssistantWidget.tsx`

Paste the contents from this patch’s `client/src/components/VoiceAssistantWidget.tsx`.

### 3.2 Mount it globally

In your JACE CRM React root (commonly `client/src/App.tsx`), add:

```tsx
import VoiceAssistantWidget from "./components/VoiceAssistantWidget";

export default function App() {
  return (
    <>
      {/* your existing app layout */}
      <VoiceAssistantWidget
        agentBaseUrl="https://YOUR-VOICE-AGENT.replit.app"
        // Optional: only show on CRM + onboarding
        onlyOnPaths={["/", "/external/onboarding"]}
      />
    </>
  );
}
```

Replace `https://YOUR-VOICE-AGENT.replit.app` with your actual voice agent URL.

## 4) Confirm it appears on BOTH pages you asked for

- Main CRM site home
- External onboarding route `/external/onboarding?...`

Because the widget is mounted globally, it will be present on both.

## 5) Troubleshooting (most common)

### Mic doesn’t work inside the iframe
- Ensure the iframe includes: `allow="microphone; autoplay"` (it does in the widget).
- Ensure the voice agent app sets `Permissions-Policy: microphone=(self)`.
- Ensure you clicked inside the iframe (browser requires user gesture).

### The iframe is blank
- The voice agent app must allow framing by JACE via CSP `frame-ancestors`.
- Make sure your agent is deployed and reachable at `/agent`.

### You want the agent to “know” onboarding context
Keep it simple: the voice agent already keeps long-term context per browser session.
If you want it to ingest onboarding fields (name/email/etc) automatically, add a `postMessage` bridge next.
