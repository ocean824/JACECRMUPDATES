import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { CalendarDays, Filter, Search } from "lucide-react";

type AssignmentListRow = {
  id: string;
  settlementSessionId: string | null;
  tradeId: number | null;
  investorId: string | null;
  investorEmail: string | null;
  investorName: string | null;
  bondName: string | null;
  purchaseAmount: string;
  purchaseDate: string;
  payoutFrequency: "weekly" | "biweekly" | "monthly" | "quarterly" | "yearly";
  payoutStartDate: string;
  payoutCount: number;
  payoutAmount: string;
  status: "active" | "cancelled" | "completed";
  nextPayoutDate: string | null;
};

function AssignmentStatusBadge({ status }: { status: AssignmentListRow["status"] }) {
  switch (status) {
    case "active":
      return <Badge className="bg-green-600 hover:bg-green-600">Active</Badge>;
    case "completed":
      return <Badge className="bg-blue-600 hover:bg-blue-600">Completed</Badge>;
    case "cancelled":
      return <Badge variant="destructive">Cancelled</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
}

export default function AssignmentsPage() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<"all" | AssignmentListRow["status"]>("all");
  const [payoutFrequency, setPayoutFrequency] = useState<"all" | AssignmentListRow["payoutFrequency"]>("all");

  const queryString = useMemo(() => {
    const p = new URLSearchParams();
    if (q.trim()) p.set("q", q.trim());
    if (status !== "all") p.set("status", status);
    if (payoutFrequency !== "all") p.set("payoutFrequency", payoutFrequency);
    p.set("limit", "200");
    const s = p.toString();
    return s ? `?${s}` : "";
  }, [q, status, payoutFrequency]);

  const { data, isLoading, error, refetch } = useQuery<AssignmentListRow[]>({
    queryKey: ["admin-assignments", queryString],
    queryFn: async () => {
      const res = await fetch(`/api/admin/assignments${queryString}`, { credentials: "include" });
      if (!res.ok) throw new Error(await res.text());
      return res.json();
    },
  });

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold">Bond Assignments</h1>
          <p className="text-muted-foreground">Purchase orders (bond assignments) and scheduled dividend payouts</p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={() => refetch()}>
            <CalendarDays className="h-4 w-4 mr-2" /> Refresh
          </Button>
          <Link href="/calendar">
            <Button>
              <CalendarDays className="h-4 w-4 mr-2" /> Payout Calendar
            </Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" /> Search + Filters
          </CardTitle>
        </CardHeader>
        <CardContent className="flex gap-3 flex-wrap items-end">
          <div className="space-y-1">
            <div className="text-sm font-medium">Search</div>
            <div className="relative">
              <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
              <Input className="pl-9 w-[320px]" placeholder="Investor email/name or bond name" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
          </div>

          <div className="space-y-1">
            <div className="text-sm font-medium">Status</div>
            <Select value={status} onValueChange={(v) => setStatus(v as any)}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1">
            <div className="text-sm font-medium">Payout Frequency</div>
            <Select value={payoutFrequency} onValueChange={(v) => setPayoutFrequency(v as any)}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="biweekly">Biweekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
                <SelectItem value="quarterly">Quarterly</SelectItem>
                <SelectItem value="yearly">Yearly</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Assignments</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="py-8 text-center text-muted-foreground">Loading assignments...</div>
          ) : error ? (
            <div className="py-8 text-center text-red-600">{String(error)}</div>
          ) : !data?.length ? (
            <div className="py-8 text-center text-muted-foreground">No assignments found.</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Investor</TableHead>
                  <TableHead>Bond</TableHead>
                  <TableHead className="text-right">Purchase</TableHead>
                  <TableHead>Frequency</TableHead>
                  <TableHead>Next Payout</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell>
                      <div className="font-medium">{a.investorName || a.investorEmail || "—"}</div>
                      <div className="text-xs text-muted-foreground">{a.investorEmail || ""}</div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{a.bondName || "—"}</div>
                      <div className="text-xs text-muted-foreground">Trade {a.tradeId ?? "—"}</div>
                    </TableCell>
                    <TableCell className="text-right font-medium">${Number(a.purchaseAmount).toLocaleString()}</TableCell>
                    <TableCell className="capitalize">{a.payoutFrequency}</TableCell>
                    <TableCell>
                      {a.nextPayoutDate ? format(new Date(a.nextPayoutDate), "MMM d, yyyy") : "—"}
                    </TableCell>
                    <TableCell>
                      <AssignmentStatusBadge status={a.status} />
                    </TableCell>
                    <TableCell className="text-right">
                      <Link href={`/assignments/${a.id}`}>
                        <Button size="sm">Open</Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
