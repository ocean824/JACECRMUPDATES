import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { Download, Save, ArrowLeft, CheckCircle } from "lucide-react";

type Assignment = {
  id: string;
  settlementSessionId: string | null;
  tradeId: number | null;
  investorId: string | null;
  investorEmail: string | null;
  investorName: string | null;
  bondId: number | null;
  bondName: string | null;
  purchaseAmount: string;
  purchaseDate: string;
  payoutFrequency: "weekly" | "biweekly" | "monthly" | "quarterly" | "yearly";
  payoutStartDate: string;
  payoutCount: number;
  payoutAmount: string;
  status: "active" | "cancelled" | "completed";
  notes: string | null;
};

type Payout = {
  id: string;
  dueDate: string;
  amount: string;
  status: "scheduled" | "paid" | "cancelled";
  paidAt?: string | null;
  paymentReference?: string | null;
  notes?: string | null;
};

function StatusBadge({ status }: { status: Payout["status"] }) {
  if (status === "paid") return <Badge className="bg-emerald-600 text-white">Paid</Badge>;
  if (status === "cancelled") return <Badge variant="destructive">Cancelled</Badge>;
  return <Badge variant="secondary">Scheduled</Badge>;
}

export default function AssignmentDetailPage({ params }: { params: { id: string } }) {
  const id = params.id;
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [payoutFilter, setPayoutFilter] = useState<"all" | "scheduled" | "paid" | "cancelled">("all");
  const [selected, setSelected] = useState<Record<string, boolean>>({});

  const assignmentQuery = useQuery({
    queryKey: ["assignment", id],
    queryFn: async () => {
      const res = await fetch(`/api/admin/assignments/${id}`, { credentials: "include" });
      if (!res.ok) throw new Error(await res.text());
      return (await res.json()) as { assignment: Assignment; stats: any };
    },
  });

  const payoutsQuery = useQuery({
    queryKey: ["assignment", id, "payouts", payoutFilter],
    queryFn: async () => {
      const res = await fetch(`/api/admin/assignments/${id}/payouts?status=${payoutFilter}`, { credentials: "include" });
      if (!res.ok) throw new Error(await res.text());
      return (await res.json()) as Payout[];
    },
    enabled: Boolean(id),
  });

  const [draft, setDraft] = useState<Partial<Assignment> | null>(null);

  // initialize draft when data loads
  if (!draft && assignmentQuery.data?.assignment) {
    setDraft(assignmentQuery.data.assignment);
  }

  const saveMutation = useMutation({
    mutationFn: async (payload: any) => apiRequest("PATCH", `/api/admin/assignments/${id}`, payload),
    onSuccess: async (r) => {
      await r.json().catch(() => null);
      toast({ title: "Saved", description: "Assignment updated." });
      queryClient.invalidateQueries({ queryKey: ["assignment", id] });
      queryClient.invalidateQueries({ queryKey: ["assignments"] });
    },
    onError: (e: any) => toast({ title: "Save failed", description: e?.message ?? String(e), variant: "destructive" }),
  });

  const markPaidMutation = useMutation({
    mutationFn: async ({ payoutIds, paymentReference }: { payoutIds: string[]; paymentReference?: string }) =>
      apiRequest("POST", `/api/admin/assignments/${id}/payouts/mark-paid`, { payoutIds, paymentReference }),
    onSuccess: async () => {
      toast({ title: "Updated", description: "Selected payouts marked paid." });
      setSelected({});
      queryClient.invalidateQueries({ queryKey: ["assignment", id, "payouts"] });
      queryClient.invalidateQueries({ queryKey: ["assignment", id] });
    },
    onError: (e: any) => toast({ title: "Update failed", description: e?.message ?? String(e), variant: "destructive" }),
  });

  const assignment = assignmentQuery.data?.assignment;
  const payouts = payoutsQuery.data ?? [];

  const selectedIds = useMemo(() => Object.entries(selected).filter(([, v]) => v).map(([k]) => k), [selected]);

  const canMarkPaid = selectedIds.length > 0;

  const exportCsv = () => {
    // Must include scheduled + paid + cancelled
    const statuses = "scheduled,paid,cancelled";
    const url = `/api/admin/assignments/${id}/payouts/export.csv?statuses=${encodeURIComponent(statuses)}`;
    window.open(url, "_blank");
  };

  if (assignmentQuery.isLoading) return <div className="p-6">Loading...</div>;
  if (assignmentQuery.error || !assignment) return <div className="p-6">Failed to load assignment.</div>;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={() => setLocation("/assignments")}> <ArrowLeft className="h-4 w-4 mr-2" />Back</Button>
          <div>
            <div className="text-2xl font-bold">{assignment.bondName ?? "Bond Assignment"}</div>
            <div className="text-sm text-muted-foreground">Assignment ID: {assignment.id}</div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={exportCsv}><Download className="h-4 w-4 mr-2" />Export CSV</Button>
          <Button
            onClick={() => {
              if (!draft) return;
              saveMutation.mutate({
                investorId: draft.investorId,
                investorEmail: draft.investorEmail,
                investorName: draft.investorName,
                bondName: draft.bondName,
                bondId: draft.bondId,
                purchaseAmount: draft.purchaseAmount,
                purchaseDate: draft.purchaseDate,
                payoutFrequency: draft.payoutFrequency,
                payoutStartDate: draft.payoutStartDate,
                payoutCount: draft.payoutCount,
                payoutAmount: draft.payoutAmount,
                status: draft.status,
                notes: draft.notes,
              });
            }}
            disabled={saveMutation.isPending}
          >
            <Save className="h-4 w-4 mr-2" />{saveMutation.isPending ? "Saving..." : "Save"}
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Assignment Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Investor Name</Label>
              <Input value={draft?.investorName ?? ""} onChange={(e) => setDraft((d) => ({ ...(d ?? {}), investorName: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Investor Email</Label>
              <Input value={draft?.investorEmail ?? ""} onChange={(e) => setDraft((d) => ({ ...(d ?? {}), investorEmail: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Trade ID</Label>
              <Input value={assignment.tradeId ?? ""} disabled />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Bond Name</Label>
              <Input value={draft?.bondName ?? ""} onChange={(e) => setDraft((d) => ({ ...(d ?? {}), bondName: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label>Purchase Amount</Label>
              <Input
                type="number"
                value={Number(draft?.purchaseAmount ?? assignment.purchaseAmount)}
                onChange={(e) => setDraft((d) => ({ ...(d ?? {}), purchaseAmount: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Purchase Date</Label>
              <Input
                type="date"
                value={draft?.purchaseDate ? format(new Date(draft.purchaseDate), "yyyy-MM-dd") : format(new Date(assignment.purchaseDate), "yyyy-MM-dd")}
                onChange={(e) => setDraft((d) => ({ ...(d ?? {}), purchaseDate: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={(draft?.status ?? assignment.status) as any} onValueChange={(v) => setDraft((d) => ({ ...(d ?? {}), status: v as any }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Separator />

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label>Payout Frequency</Label>
              <Select value={(draft?.payoutFrequency ?? assignment.payoutFrequency) as any} onValueChange={(v) => setDraft((d) => ({ ...(d ?? {}), payoutFrequency: v as any }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="biweekly">Biweekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="quarterly">Quarterly</SelectItem>
                  <SelectItem value="yearly">Yearly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>First Payout Date</Label>
              <Input
                type="date"
                value={draft?.payoutStartDate ? format(new Date(draft.payoutStartDate), "yyyy-MM-dd") : format(new Date(assignment.payoutStartDate), "yyyy-MM-dd")}
                onChange={(e) => setDraft((d) => ({ ...(d ?? {}), payoutStartDate: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label># of Payouts</Label>
              <Input
                type="number"
                value={Number(draft?.payoutCount ?? assignment.payoutCount)}
                onChange={(e) => setDraft((d) => ({ ...(d ?? {}), payoutCount: Number(e.target.value) }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Payout Amount</Label>
              <Input
                type="number"
                value={Number(draft?.payoutAmount ?? assignment.payoutAmount)}
                onChange={(e) => setDraft((d) => ({ ...(d ?? {}), payoutAmount: e.target.value }))}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Notes</Label>
            <Textarea value={draft?.notes ?? ""} onChange={(e) => setDraft((d) => ({ ...(d ?? {}), notes: e.target.value }))} />
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              onClick={() => {
                if (!draft) return;
                saveMutation.mutate({
                  payoutFrequency: draft.payoutFrequency,
                  payoutStartDate: draft.payoutStartDate,
                  payoutCount: draft.payoutCount,
                  payoutAmount: draft.payoutAmount,
                  regeneratePayouts: true,
                });
              }}
              disabled={saveMutation.isPending}
            >
              Regenerate Schedule
            </Button>
            <div className="text-xs text-muted-foreground">(Keeps PAID payouts; replaces scheduled/cancelled)</div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Payouts</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div className="flex items-center gap-2">
              <Label className="text-sm">Filter</Label>
              <Select value={payoutFilter} onValueChange={(v) => setPayoutFilter(v as any)}>
                <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Button
                onClick={() => markPaidMutation.mutate({ payoutIds: selectedIds })}
                disabled={!canMarkPaid || markPaidMutation.isPending}
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                {markPaidMutation.isPending ? "Updating..." : `Mark Paid (${selectedIds.length})`}
              </Button>
            </div>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[48px]"></TableHead>
                <TableHead>Due Date</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Paid At</TableHead>
                <TableHead>Payment Ref</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {payouts.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-10 text-muted-foreground">
                    No payouts.
                  </TableCell>
                </TableRow>
              ) : (
                payouts.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>
                      <Checkbox
                        checked={Boolean(selected[p.id])}
                        disabled={p.status !== "scheduled"}
                        onCheckedChange={(v) => setSelected((s) => ({ ...s, [p.id]: Boolean(v) }))}
                      />
                    </TableCell>
                    <TableCell>{format(new Date(p.dueDate), "MMM d, yyyy")}</TableCell>
                    <TableCell className="font-medium">${Number(p.amount).toLocaleString()}</TableCell>
                    <TableCell><StatusBadge status={p.status} /></TableCell>
                    <TableCell>{p.paidAt ? format(new Date(p.paidAt), "MMM d, yyyy") : "—"}</TableCell>
                    <TableCell className="max-w-[220px] truncate">{p.paymentReference ?? "—"}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
