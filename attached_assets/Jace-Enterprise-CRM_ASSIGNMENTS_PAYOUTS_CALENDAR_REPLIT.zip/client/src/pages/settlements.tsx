import { useEffect, useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { CheckCircle, XCircle, FileText, RefreshCw, DollarSign, MoreHorizontal, PlusCircle } from "lucide-react";

// Types for settlement session data
interface SettlementSessionRow {
  sessionId: string;
  tradeId: number;
  investorId: string | null;
  bondaiInvestorId?: number | null;
  investorEmail: string;
  investorName: string;
  bondName: string;
  bondId?: number | null;
  amount: string;
  status: "created" | "submitted" | "settled" | "cancelled";
  complianceStatus: "pending" | "in_progress" | "complete";
  paymentStatus: "pending" | "confirmed";
  paymentReference?: string;
  escrowAccountId?: string;
  createdAt: string;
  updatedAt: string;
  settledAt?: string;
  cancelledAt?: string;
  failureReason?: string;
}

interface EscrowAccount {
  id: string;
  name: string;
  bankName: string;
  accountNumberLast4: string;
  routingNumberLast4: string;
  createdAt: string;
}

interface InvestorListItem {
  id: string;
  email: string;
  firstName?: string | null;
  lastName?: string | null;
}

type AssignmentDraft = {
  investorId: string | null;
  investorEmail: string | null;
  investorName: string | null;
  bondName: string | null;
  bondId: number | null;
  purchaseAmount: string;
  payoutFrequency: "weekly" | "biweekly" | "monthly" | "quarterly" | "yearly";
  payoutStartDate: string; // YYYY-MM-DD
  payoutCount: number;
  payoutAmount: string;
  notes: string;
  regeneratePayouts: boolean;
};

function missingFieldsForSession(session: SettlementSessionRow): string[] {
  const missing: string[] = [];
  if (!session.investorId) missing.push("investorId");
  if (!session.investorEmail) missing.push("investorEmail");
  if (!session.bondName) missing.push("bondName");
  const amt = Number(session.amount);
  if (!Number.isFinite(amt) || amt <= 0) missing.push("amount");
  if (!session.tradeId) missing.push("tradeId");
  return missing;
}

function isoToDateInput(value?: string): string {
  if (!value) return "";
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return "";
  return d.toISOString().slice(0, 10);
}

function SettlementStatusBadge({ status }: { status: string }) {
  const variant =
    status === "settled"
      ? "default"
      : status === "submitted"
        ? "secondary"
        : status === "cancelled"
          ? "destructive"
          : "outline";

  return <Badge variant={variant as any}>{status.toUpperCase()}</Badge>;
}

function ComplianceStatusBadge({ status }: { status: string }) {
  const variant = status === "complete" ? "default" : status === "in_progress" ? "secondary" : "outline";
  return <Badge variant={variant as any}>{status.replace("_", " ").toUpperCase()}</Badge>;
}

function PaymentStatusBadge({ status }: { status: string }) {
  const variant = status === "confirmed" ? "default" : "outline";
  return <Badge variant={variant as any}>{status.toUpperCase()}</Badge>;
}

function PayloadStatusBadge({ missing }: { missing: string[] }) {
  if (!missing.length) {
    return <Badge variant="secondary">Complete</Badge>;
  }
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge variant="destructive">Incomplete Payload</Badge>
        </TooltipTrigger>
        <TooltipContent>
          <div className="text-sm">Missing {missing.join(", ")}</div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function formatDate(date: string | undefined) {
  if (!date) return "-";
  return format(new Date(date), "MMM dd, yyyy HH:mm");
}

function formatCurrency(amount: string) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(parseFloat(amount));
}

function InboxTable({
  sessions,
  escrowAccounts,
  onConfirm,
  onCancel,
  onSyncAssignment,
}: {
  sessions: SettlementSessionRow[];
  escrowAccounts: EscrowAccount[];
  onConfirm: (session: SettlementSessionRow) => void;
  onCancel: (session: SettlementSessionRow) => void;
  onSyncAssignment: (session: SettlementSessionRow) => void;
}) {
  if (!sessions.length) {
    return <div className="text-center py-8 text-muted-foreground">No settlement sessions found</div>;
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Trade ID</TableHead>
          <TableHead>Investor</TableHead>
          <TableHead>Bond</TableHead>
          <TableHead>Amount</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Compliance</TableHead>
          <TableHead>Payment</TableHead>
          <TableHead>Payload Status</TableHead>
          <TableHead>Created</TableHead>
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {sessions.map((session) => {
          const missing = missingFieldsForSession(session);
          const isIncomplete = missing.length > 0;
          return (
            <TableRow key={session.sessionId}>
              <TableCell className="font-medium">#{session.tradeId}</TableCell>
              <TableCell>
                <div className="space-y-1">
                  <div>{session.investorName || "-"}</div>
                  <div className="text-sm text-muted-foreground">{session.investorEmail || "-"}</div>
                </div>
              </TableCell>
              <TableCell>
                <div className="space-y-1">
                  <div>{session.bondName || "-"}</div>
                  {session.bondId ? <div className="text-sm text-muted-foreground">ID: {session.bondId}</div> : null}
                </div>
              </TableCell>
              <TableCell className="font-medium">{formatCurrency(session.amount)}</TableCell>
              <TableCell>
                <SettlementStatusBadge status={session.status} />
              </TableCell>
              <TableCell>
                <ComplianceStatusBadge status={session.complianceStatus} />
              </TableCell>
              <TableCell>
                <PaymentStatusBadge status={session.paymentStatus} />
              </TableCell>
              <TableCell>
                <PayloadStatusBadge missing={missing} />
              </TableCell>
              <TableCell className="text-sm text-muted-foreground">{formatDate(session.createdAt)}</TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  {session.status === "submitted" && isIncomplete && (
                    <Button size="sm" variant="destructive" onClick={() => onSyncAssignment(session)}>
                      <PlusCircle className="h-4 w-4 mr-1" />
                      Quick Add
                    </Button>
                  )}

                  {session.status === "submitted" && (
                    <>
                      <Button
                        size="sm"
                        variant="default"
                        onClick={() => onConfirm(session)}
                        disabled={session.complianceStatus !== "complete"}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Confirm
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => onCancel(session)}>
                        <XCircle className="h-4 w-4 mr-1" />
                        Cancel
                      </Button>
                    </>
                  )}

                  {session.status === "settled" && (
                    <a
                      href={`/api/admin/settlements/${session.sessionId}/receipt`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex"
                    >
                      <Button size="sm" variant="outline">
                        <FileText className="h-4 w-4 mr-1" />
                        Receipt
                      </Button>
                    </a>
                  )}

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button size="sm" variant="outline">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuItem onSelect={() => onSyncAssignment(session)}>
                        Create/Sync Assignment
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem disabled>
                        Session ID: {session.sessionId.slice(0, 8)}…
                      </DropdownMenuItem>
                      {session.escrowAccountId ? (
                        <DropdownMenuItem disabled>
                          Escrow: {escrowAccounts.find((e) => e.id === session.escrowAccountId)?.name ?? session.escrowAccountId}
                        </DropdownMenuItem>
                      ) : null}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {session.status === "submitted" && session.complianceStatus !== "complete" && (
                  <div className="text-xs text-muted-foreground mt-1">Compliance incomplete — cannot confirm.</div>
                )}
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}

export default function Settlements() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [selectedStatus, setSelectedStatus] = useState<string>("submitted");
  const [selectedSession, setSelectedSession] = useState<SettlementSessionRow | null>(null);
  const [actionType, setActionType] = useState<"confirm" | "cancel" | null>(null);

  const [confirmNotes, setConfirmNotes] = useState("");
  const [cancelReason, setCancelReason] = useState("");
  const [selectedEscrowAccount, setSelectedEscrowAccount] = useState<string>("");

  const [syncDialogOpen, setSyncDialogOpen] = useState(false);
  const [syncSession, setSyncSession] = useState<SettlementSessionRow | null>(null);

  const [assignmentDraft, setAssignmentDraft] = useState<AssignmentDraft | null>(null);

  // Fetch settlement sessions
  const { data: sessions = [], isLoading, error, refetch } = useQuery<SettlementSessionRow[]>({
    queryKey: ["settlements-inbox", selectedStatus],
    queryFn: async () => {
      const response = await fetch(`/api/admin/settlements?status=${selectedStatus}`, {
        credentials: "include",
      });
      if (!response.ok) throw new Error("Failed to fetch settlements");
      return response.json();
    },
    refetchInterval: selectedStatus === "submitted" ? 30000 : false,
  });

  // Fetch escrow accounts
  const { data: escrowAccounts = [] } = useQuery<EscrowAccount[]>({
    queryKey: ["escrow-accounts"],
    queryFn: async () => {
      const response = await fetch("/api/escrow-accounts", { credentials: "include" });
      if (!response.ok) return [];
      return response.json();
    },
  });

  // Investors list for selecting investorId in quick sync / confirm
  const { data: investors = [] } = useQuery<InvestorListItem[]>({
    queryKey: ["investors-list"],
    queryFn: async () => {
      const response = await fetch("/api/investors", { credentials: "include" });
      if (!response.ok) return [];
      return response.json();
    },
  });

  const confirmSettlement = useMutation({
    mutationFn: async ({
      sessionId,
      notes,
      escrowAccountId,
      assignment,
    }: {
      sessionId: string;
      notes: string;
      escrowAccountId: string | null;
      assignment?: any;
    }) => {
      const response = await apiRequest("POST", `/api/admin/settlements/${sessionId}/confirm`, {
        notes,
        escrowAccountId,
        assignment,
      });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Settlement confirmed",
        description:
          data?.assignment?.id
            ? `Receipt generated. Assignment synced (${data.assignment.id.slice(0, 8)}…).`
            : "Receipt generated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["settlements-inbox"] });
      queryClient.invalidateQueries({ queryKey: ["escrow-accounts"] });
      setSelectedSession(null);
      setActionType(null);
      setConfirmNotes("");
      setSelectedEscrowAccount("");
      setAssignmentDraft(null);
    },
    onError: (err: any) => {
      toast({
        title: "Error",
        description: err?.message || "Failed to confirm settlement",
        variant: "destructive",
      });
    },
  });

  const cancelSettlement = useMutation({
    mutationFn: async ({ sessionId, reason }: { sessionId: string; reason: string }) => {
      const response = await apiRequest("POST", `/api/admin/settlements/${sessionId}/cancel`, { reason });
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Settlement cancelled", description: "Settlement was cancelled successfully" });
      queryClient.invalidateQueries({ queryKey: ["settlements-inbox"] });
      setSelectedSession(null);
      setActionType(null);
      setCancelReason("");
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err?.message || "Failed to cancel settlement", variant: "destructive" });
    },
  });

  const syncAssignment = useMutation({
    mutationFn: async ({ sessionId, assignment }: { sessionId: string; assignment: any }) => {
      const response = await apiRequest("POST", `/api/admin/settlements/${sessionId}/sync-assignment`, { assignment });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Assignment synced",
        description: data?.assignment?.id
          ? `Assignment ${data.assignment.id.slice(0, 8)}… synced. Payouts generated: ${data.payoutsGenerated ?? 0}.`
          : "Assignment synced.",
      });
      queryClient.invalidateQueries({ queryKey: ["settlements-inbox"] });
      queryClient.invalidateQueries({ queryKey: ["assignments"] });
      setSyncDialogOpen(false);
      setSyncSession(null);
    },
    onError: (err: any) => {
      toast({ title: "Error", description: err?.message || "Failed to sync assignment", variant: "destructive" });
    },
  });

  const filteredSessions = useMemo(() => {
    return sessions || [];
  }, [sessions]);

  const handleConfirm = (session: SettlementSessionRow) => {
    setSelectedSession(session);
    setActionType("confirm");

    const now = new Date();
    const start = new Date(now.getTime() + 30 * 86400000);

    // Prefill assignment draft for confirmation modal
    setAssignmentDraft({
      investorId: session.investorId ?? null,
      investorEmail: session.investorEmail ?? null,
      investorName: session.investorName ?? null,
      bondName: session.bondName ?? null,
      bondId: (session.bondId ?? null) as any,
      purchaseAmount: String(session.amount ?? "0"),
      payoutFrequency: "monthly",
      payoutStartDate: start.toISOString().slice(0, 10),
      payoutCount: 12,
      payoutAmount: "0",
      notes: "",
      regeneratePayouts: false,
    });

    if (escrowAccounts.length > 0 && !selectedEscrowAccount) {
      setSelectedEscrowAccount(escrowAccounts[0].id);
    }
  };

  const handleCancel = (session: SettlementSessionRow) => {
    setSelectedSession(session);
    setActionType("cancel");
    setCancelReason("");
  };

  const openSync = (session: SettlementSessionRow) => {
    setSyncSession(session);
    setSyncDialogOpen(true);

    const now = new Date();
    const start = new Date(now.getTime() + 30 * 86400000);

    setAssignmentDraft({
      investorId: session.investorId ?? null,
      investorEmail: session.investorEmail ?? null,
      investorName: session.investorName ?? null,
      bondName: session.bondName ?? null,
      bondId: (session.bondId ?? null) as any,
      purchaseAmount: String(session.amount ?? "0"),
      payoutFrequency: "monthly",
      payoutStartDate: start.toISOString().slice(0, 10),
      payoutCount: 12,
      payoutAmount: "0",
      notes: "",
      regeneratePayouts: true,
    });
  };

  // Auto-show modal if navigated directly? not needed.
  useEffect(() => {
    if (!selectedSession) {
      setConfirmNotes("");
      setCancelReason("");
    }
  }, [selectedSession]);

  const canConfirm = selectedSession && actionType === "confirm";
  const canCancel = selectedSession && actionType === "cancel";

  const missing = selectedSession ? missingFieldsForSession(selectedSession) : [];

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading settlements...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-destructive">Error loading settlements</div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Settlement Inbox</h1>
          <p className="text-muted-foreground">Review BondAI settlements, confirm escrow, and sync assignments + payouts.</p>
        </div>
        <Button onClick={() => refetch()} variant="outline" size="sm" disabled={isLoading}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Settlement Sessions</CardTitle>
          <div className="flex items-center gap-2">
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="submitted">Pending</SelectItem>
                <SelectItem value="settled">Confirmed</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="created">Created</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <InboxTable
            sessions={filteredSessions}
            escrowAccounts={escrowAccounts}
            onConfirm={handleConfirm}
            onCancel={handleCancel}
            onSyncAssignment={openSync}
          />
        </CardContent>
      </Card>

      {/* Confirm / Cancel dialogs */}
      <Dialog open={!!selectedSession && !!actionType} onOpenChange={(open) => !open && setSelectedSession(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {actionType === "confirm" ? "Confirm Settlement" : actionType === "cancel" ? "Cancel Settlement" : ""}
            </DialogTitle>
          </DialogHeader>

          {selectedSession && actionType === "confirm" && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Trade ID</label>
                  <div className="text-sm">#{selectedSession.tradeId}</div>
                </div>
                <div>
                  <label className="text-sm font-medium">Amount</label>
                  <div className="text-sm font-medium">{formatCurrency(selectedSession.amount)}</div>
                </div>
                <div>
                  <label className="text-sm font-medium">Investor</label>
                  <div className="text-sm">{selectedSession.investorName}</div>
                  <div className="text-xs text-muted-foreground">{selectedSession.investorEmail}</div>
                </div>
                <div>
                  <label className="text-sm font-medium">Bond</label>
                  <div className="text-sm">{selectedSession.bondName}</div>
                </div>
              </div>

              {missing.length > 0 && (
                <div className="rounded-md border border-destructive/40 bg-destructive/5 p-3">
                  <div className="font-medium text-sm text-destructive">Payload incomplete</div>
                  <div className="text-xs text-muted-foreground">Missing fields: {missing.join(", ")}</div>
                  <div className="text-xs text-muted-foreground mt-1">You can still confirm, but you should fill the assignment overrides below.</div>
                </div>
              )}

              <div>
                <label className="text-sm font-medium">Escrow Account</label>
                <Select value={selectedEscrowAccount} onValueChange={setSelectedEscrowAccount}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select escrow account" />
                  </SelectTrigger>
                  <SelectContent>
                    {escrowAccounts.map((account) => (
                      <SelectItem key={account.id} value={account.id}>
                        {account.name} - {account.bankName} (****{account.accountNumberLast4})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium">Notes (optional)</label>
                <Textarea
                  value={confirmNotes}
                  onChange={(e) => setConfirmNotes(e.target.value)}
                  placeholder="Confirmation notes..."
                  className="mt-2"
                />
              </div>

              <Separator />

              {/* Assignment creation/edit inside the confirmation modal */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-semibold">Assignment & Payout Schedule</div>
                    <div className="text-xs text-muted-foreground">Auto-created on confirm; edit fields here before confirming.</div>
                  </div>
                  <Badge variant="outline">Auto-create</Badge>
                </div>

                {assignmentDraft && (
                  <div className="grid grid-cols-2 gap-3">
                    <div className="col-span-2">
                      <label className="text-xs font-medium">Investor</label>
                      <Select
                        value={assignmentDraft.investorId ?? ""}
                        onValueChange={(v) =>
                          setAssignmentDraft((d) =>
                            d
                              ? {
                                  ...d,
                                  investorId: v || null,
                                  investorEmail:
                                    investors.find((i) => i.id === v)?.email ?? d.investorEmail,
                                  investorName:
                                    investors.find((i) => i.id === v)
                                      ? `${investors.find((i) => i.id === v)?.firstName ?? ""} ${
                                          investors.find((i) => i.id === v)?.lastName ?? ""
                                        }`.trim() || d.investorName
                                      : d.investorName,
                                }
                              : d
                          )
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select investor (optional)" />
                        </SelectTrigger>
                        <SelectContent>
                          {investors.slice(0, 250).map((inv) => (
                            <SelectItem key={inv.id} value={inv.id}>
                              {(inv.firstName || inv.lastName) ? `${inv.firstName ?? ""} ${inv.lastName ?? ""}`.trim() : inv.email} — {inv.email}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <div>
                          <label className="text-xs font-medium">Investor Email</label>
                          <Input
                            className="mt-1"
                            value={assignmentDraft.investorEmail ?? ""}
                            onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, investorEmail: e.target.value } : d))}
                            placeholder="investor@example.com"
                          />
                        </div>
                        <div>
                          <label className="text-xs font-medium">Investor Name</label>
                          <Input
                            className="mt-1"
                            value={assignmentDraft.investorName ?? ""}
                            onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, investorName: e.target.value } : d))}
                            placeholder="Investor Name"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="col-span-2">
                      <label className="text-xs font-medium">Bond Name</label>
                      <Input
                        className="mt-1"
                        value={assignmentDraft.bondName ?? ""}
                        onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, bondName: e.target.value } : d))}
                        placeholder="Bond Name"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-medium">Purchase Amount</label>
                      <Input
                        className="mt-1"
                        value={assignmentDraft.purchaseAmount}
                        onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, purchaseAmount: e.target.value } : d))}
                      />
                    </div>

                    <div>
                      <label className="text-xs font-medium">Payout Amount (per period)</label>
                      <Input
                        className="mt-1"
                        value={assignmentDraft.payoutAmount}
                        onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, payoutAmount: e.target.value } : d))}
                        placeholder="0.00"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-medium">Payout Frequency</label>
                      <Select
                        value={assignmentDraft.payoutFrequency}
                        onValueChange={(v) => setAssignmentDraft((d) => (d ? { ...d, payoutFrequency: v as any } : d))}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="biweekly">Biweekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                          <SelectItem value="quarterly">Quarterly</SelectItem>
                          <SelectItem value="yearly">Yearly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <label className="text-xs font-medium">Payout Start Date</label>
                      <Input
                        type="date"
                        className="mt-1"
                        value={assignmentDraft.payoutStartDate}
                        onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, payoutStartDate: e.target.value } : d))}
                      />
                    </div>

                    <div>
                      <label className="text-xs font-medium"># of Payouts</label>
                      <Input
                        className="mt-1"
                        type="number"
                        min={1}
                        value={assignmentDraft.payoutCount}
                        onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, payoutCount: Number(e.target.value) } : d))}
                      />
                    </div>

                    <div className="col-span-2">
                      <label className="text-xs font-medium">Assignment Notes</label>
                      <Textarea
                        className="mt-1"
                        value={assignmentDraft.notes}
                        onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, notes: e.target.value } : d))}
                        placeholder="Optional notes for assignment/payout schedule"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {selectedSession && actionType === "cancel" && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Cancel reason</label>
                <Textarea
                  value={cancelReason}
                  onChange={(e) => setCancelReason(e.target.value)}
                  placeholder="Reason for cancellation..."
                  className="mt-2"
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedSession(null)}>
              Close
            </Button>

            {canConfirm && selectedSession && (
              <Button
                onClick={() =>
                  confirmSettlement.mutate({
                    sessionId: selectedSession.sessionId,
                    notes: confirmNotes,
                    escrowAccountId: selectedEscrowAccount || null,
                    assignment: assignmentDraft
                      ? {
                          investorId: assignmentDraft.investorId,
                          investorEmail: assignmentDraft.investorEmail,
                          investorName: assignmentDraft.investorName,
                          bondName: assignmentDraft.bondName,
                          bondId: assignmentDraft.bondId,
                          purchaseAmount: assignmentDraft.purchaseAmount,
                          payoutFrequency: assignmentDraft.payoutFrequency,
                          payoutStartDate: assignmentDraft.payoutStartDate,
                          payoutCount: assignmentDraft.payoutCount,
                          payoutAmount: assignmentDraft.payoutAmount,
                          notes: assignmentDraft.notes,
                          regeneratePayouts: assignmentDraft.regeneratePayouts,
                        }
                      : undefined,
                  })
                }
                disabled={confirmSettlement.isPending}
              >
                <DollarSign className="h-4 w-4 mr-2" />
                {confirmSettlement.isPending ? "Confirming..." : "Confirm Settlement"}
              </Button>
            )}

            {canCancel && selectedSession && (
              <Button
                variant="destructive"
                onClick={() => cancelSettlement.mutate({ sessionId: selectedSession.sessionId, reason: cancelReason || "Cancelled" })}
                disabled={cancelSettlement.isPending}
              >
                {cancelSettlement.isPending ? "Cancelling..." : "Cancel Settlement"}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Quick Add / Sync Assignment Dialog */}
      <Dialog open={syncDialogOpen} onOpenChange={setSyncDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create/Sync Assignment</DialogTitle>
          </DialogHeader>

          {syncSession && assignmentDraft && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Settlement Trade</label>
                  <div className="text-sm">#{syncSession.tradeId}</div>
                  <div className="text-xs text-muted-foreground">Session {syncSession.sessionId.slice(0, 8)}…</div>
                </div>
                <div>
                  <label className="text-sm font-medium">Purchase Amount</label>
                  <div className="text-sm font-medium">{formatCurrency(syncSession.amount)}</div>
                </div>
              </div>

              <div className="rounded-md border p-3">
                <div className="text-sm font-medium">Payload Status</div>
                <div className="mt-2">
                  <PayloadStatusBadge missing={missingFieldsForSession(syncSession)} />
                </div>
                {missingFieldsForSession(syncSession).length > 0 && (
                  <div className="text-xs text-muted-foreground mt-2">Fill the missing fields below and click Sync.</div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="col-span-2">
                  <label className="text-xs font-medium">Investor</label>
                  <Select
                    value={assignmentDraft.investorId ?? ""}
                    onValueChange={(v) =>
                      setAssignmentDraft((d) =>
                        d
                          ? {
                              ...d,
                              investorId: v || null,
                              investorEmail: investors.find((i) => i.id === v)?.email ?? d.investorEmail,
                            }
                          : d
                      )
                    }
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select investor (recommended)" />
                    </SelectTrigger>
                    <SelectContent>
                      {investors.slice(0, 250).map((inv) => (
                        <SelectItem key={inv.id} value={inv.id}>
                          {(inv.firstName || inv.lastName) ? `${inv.firstName ?? ""} ${inv.lastName ?? ""}`.trim() : inv.email} — {inv.email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-xs font-medium">Investor Email</label>
                  <Input
                    className="mt-1"
                    value={assignmentDraft.investorEmail ?? ""}
                    onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, investorEmail: e.target.value } : d))}
                  />
                </div>
                <div>
                  <label className="text-xs font-medium">Investor Name</label>
                  <Input
                    className="mt-1"
                    value={assignmentDraft.investorName ?? ""}
                    onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, investorName: e.target.value } : d))}
                  />
                </div>

                <div className="col-span-2">
                  <label className="text-xs font-medium">Bond Name</label>
                  <Input
                    className="mt-1"
                    value={assignmentDraft.bondName ?? ""}
                    onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, bondName: e.target.value } : d))}
                  />
                </div>

                <div>
                  <label className="text-xs font-medium">Payout Frequency</label>
                  <Select
                    value={assignmentDraft.payoutFrequency}
                    onValueChange={(v) => setAssignmentDraft((d) => (d ? { ...d, payoutFrequency: v as any } : d))}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="biweekly">Biweekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="quarterly">Quarterly</SelectItem>
                      <SelectItem value="yearly">Yearly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-xs font-medium">Payout Start Date</label>
                  <Input
                    type="date"
                    className="mt-1"
                    value={assignmentDraft.payoutStartDate}
                    onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, payoutStartDate: e.target.value } : d))}
                  />
                </div>

                <div>
                  <label className="text-xs font-medium"># of Payouts</label>
                  <Input
                    type="number"
                    min={1}
                    className="mt-1"
                    value={assignmentDraft.payoutCount}
                    onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, payoutCount: Number(e.target.value) } : d))}
                  />
                </div>

                <div>
                  <label className="text-xs font-medium">Payout Amount</label>
                  <Input
                    className="mt-1"
                    value={assignmentDraft.payoutAmount}
                    onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, payoutAmount: e.target.value } : d))}
                  />
                </div>

                <div className="col-span-2">
                  <label className="text-xs font-medium">Notes</label>
                  <Textarea
                    className="mt-1"
                    value={assignmentDraft.notes}
                    onChange={(e) => setAssignmentDraft((d) => (d ? { ...d, notes: e.target.value } : d))}
                  />
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setSyncDialogOpen(false)}>
              Close
            </Button>
            <Button
              onClick={() => {
                if (!syncSession || !assignmentDraft) return;
                syncAssignment.mutate({
                  sessionId: syncSession.sessionId,
                  assignment: {
                    investorId: assignmentDraft.investorId,
                    investorEmail: assignmentDraft.investorEmail,
                    investorName: assignmentDraft.investorName,
                    bondName: assignmentDraft.bondName,
                    bondId: assignmentDraft.bondId,
                    purchaseAmount: assignmentDraft.purchaseAmount,
                    payoutFrequency: assignmentDraft.payoutFrequency,
                    payoutStartDate: assignmentDraft.payoutStartDate,
                    payoutCount: assignmentDraft.payoutCount,
                    payoutAmount: assignmentDraft.payoutAmount,
                    notes: assignmentDraft.notes,
                    regeneratePayouts: assignmentDraft.regeneratePayouts,
                  },
                });
              }}
              disabled={syncAssignment.isPending}
            >
              {syncAssignment.isPending ? "Syncing..." : "Create/Sync Assignment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
