import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "../db";
import {
  assignmentPayouts,
  bondAssignments,
  investors,
  settlementSessions,
  type BondAssignment,
} from "@shared/schema";

export type AssignmentUpsertOverrides = {
  investorId?: string | null;
  investorEmail?: string | null;
  investorName?: string | null;
  bondName?: string | null;
  bondId?: number | null;
  purchaseAmount?: number | string | null;
  payoutFrequency?: "weekly" | "biweekly" | "monthly" | "quarterly" | "yearly" | null;
  payoutStartDate?: string | Date | null;
  payoutCount?: number | null;
  payoutAmount?: number | string | null;
  notes?: string | null;
  status?: "active" | "cancelled" | "completed" | null;
  regeneratePayouts?: boolean;
};

export function computeMissingSettlementFields(s: {
  investorId: string | null;
  investorEmail: string | null;
  bondName: string | null;
  amount: any;
  tradeId: number | null;
}): string[] {
  const missing: string[] = [];
  if (!s.investorId) missing.push("investorId");
  if (!s.investorEmail) missing.push("investorEmail");
  if (!s.bondName) missing.push("bondName");
  const amt = Number(s.amount);
  if (!Number.isFinite(amt) || amt <= 0) missing.push("amount");
  if (!s.tradeId) missing.push("tradeId");
  return missing;
}

function addDays(d: Date, days: number) {
  const x = new Date(d);
  x.setDate(x.getDate() + days);
  return x;
}

function addMonths(d: Date, months: number) {
  const x = new Date(d);
  x.setMonth(x.getMonth() + months);
  return x;
}

export function addFrequency(base: Date, freq: AssignmentUpsertOverrides["payoutFrequency"]): Date {
  switch (freq) {
    case "weekly":
      return addDays(base, 7);
    case "biweekly":
      return addDays(base, 14);
    case "quarterly":
      return addMonths(base, 3);
    case "yearly":
      return addMonths(base, 12);
    case "monthly":
    default:
      return addMonths(base, 1);
  }
}

export function coerceDate(value: string | Date | null | undefined): Date | null {
  if (!value) return null;
  if (value instanceof Date) return value;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  return d;
}

export async function findInvestorIdByEmail(email: string): Promise<string | null> {
  const [inv] = await db
    .select({ id: investors.id, email: investors.email })
    .from(investors)
    .where(sql`lower(${investors.email}) = lower(${email})`)
    .orderBy(desc(investors.createdAt))
    .limit(1);
  return inv?.id ?? null;
}

export async function getAssignmentBySettlementSessionId(sessionId: string): Promise<BondAssignment | null> {
  const [row] = await db
    .select()
    .from(bondAssignments)
    .where(eq(bondAssignments.settlementSessionId, sessionId))
    .limit(1);
  return row ?? null;
}

export async function upsertAssignmentFromSettlement(args: {
  ownerUserId: string;
  sessionId: string;
  overrides?: AssignmentUpsertOverrides;
}): Promise<{ assignment: BondAssignment; created: boolean; payoutsGenerated: number }> {
  const { ownerUserId, sessionId } = args;
  const overrides = args.overrides || {};

  const [settlement] = await db
    .select()
    .from(settlementSessions)
    .where(eq(settlementSessions.sessionId, sessionId))
    .limit(1);

  if (!settlement) {
    throw new Error("Settlement session not found");
  }

  const purchaseAmount = overrides.purchaseAmount != null ? Number(overrides.purchaseAmount) : Number(settlement.amount);
  if (!Number.isFinite(purchaseAmount) || purchaseAmount <= 0) {
    throw new Error("Invalid purchaseAmount");
  }

  const derivedInvestorEmail =
    overrides.investorEmail ?? settlement.investorEmail ?? null;
  const derivedInvestorName =
    overrides.investorName ?? settlement.investorName ?? null;

  let investorId = overrides.investorId ?? settlement.investorId ?? null;
  if (!investorId && derivedInvestorEmail) {
    investorId = await findInvestorIdByEmail(derivedInvestorEmail);
  }

  const payoutFrequency = (overrides.payoutFrequency ?? "monthly") as any;

  const startFromOverride = coerceDate(overrides.payoutStartDate ?? null);
  const defaultStart = settlement.settledAt ? addDays(new Date(settlement.settledAt), 30) : addDays(new Date(), 30);
  const payoutStartDate = startFromOverride ?? defaultStart;

  const payoutCount = Math.max(1, Number(overrides.payoutCount ?? 12));
  const payoutAmount = Number(overrides.payoutAmount ?? 0);
  const now = new Date();

  const existing = await getAssignmentBySettlementSessionId(sessionId);

  const patch: any = {
    userId: ownerUserId,
    settlementSessionId: sessionId,
    tradeId: settlement.tradeId,
    investorId,
    investorEmail: derivedInvestorEmail,
    investorName: derivedInvestorName,
    bondId: overrides.bondId ?? settlement.bondId ?? null,
    bondName: overrides.bondName ?? settlement.bondName ?? null,
    purchaseAmount: purchaseAmount.toFixed(2),
    purchaseDate: settlement.settledAt ?? settlement.createdAt ?? now,
    payoutFrequency,
    payoutStartDate,
    payoutCount,
    payoutAmount: Number.isFinite(payoutAmount) ? payoutAmount.toFixed(2) : "0",
    status: overrides.status ?? "active",
    notes: overrides.notes ?? null,
    updatedAt: now,
  };

  let assignment: BondAssignment;
  let created = false;

  if (existing) {
    const [updated] = await db
      .update(bondAssignments)
      .set(patch)
      .where(eq(bondAssignments.id, existing.id))
      .returning();
    assignment = updated;
  } else {
    created = true;
    const [inserted] = await db
      .insert(bondAssignments)
      .values({
        ...patch,
        createdAt: now,
      })
      .returning();
    assignment = inserted;
  }

  // Decide whether to generate payouts
  let payoutsGenerated = 0;
  const regenerate = Boolean(overrides.regeneratePayouts);

  if (regenerate) {
    // Keep PAID payouts, wipe everything else and regenerate
    await db
      .delete(assignmentPayouts)
      .where(
        and(
          eq(assignmentPayouts.assignmentId, assignment.id),
          inArray(assignmentPayouts.status, ["scheduled", "cancelled"] as any)
        )
      );
  }

  const [countRow] = await db
    .select({ count: sql<number>`count(*)` })
    .from(assignmentPayouts)
    .where(eq(assignmentPayouts.assignmentId, assignment.id));

  const existingCount = Number(countRow?.count || 0);

  if (existingCount === 0 || regenerate) {
    // Generate schedule
    const dueDates: Date[] = [];
    let cursor = new Date(payoutStartDate);
    for (let i = 0; i < payoutCount; i++) {
      dueDates.push(new Date(cursor));
      cursor = addFrequency(cursor, payoutFrequency);
    }

    const rows = dueDates.map((dueDate) => ({
      userId: ownerUserId,
      assignmentId: assignment.id,
      dueDate,
      amount: patch.payoutAmount,
      status: "scheduled" as const,
      createdAt: now,
      updatedAt: now,
    }));

    if (rows.length > 0) {
      const inserted = await db.insert(assignmentPayouts).values(rows).returning({ id: assignmentPayouts.id });
      payoutsGenerated = inserted.length;
    }
  }

  return { assignment, created, payoutsGenerated };
}

export async function markPayoutsPaid(args: {
  ownerUserId: string;
  payoutIds: string[];
  paymentReference?: string | null;
  paidAt?: Date | null;
}): Promise<number> {
  if (!args.payoutIds.length) return 0;
  const now = new Date();
  const paidAt = args.paidAt ?? now;

  const updated = await db
    .update(assignmentPayouts)
    .set({
      status: "paid" as any,
      paidAt,
      paidByUserId: args.ownerUserId,
      paymentReference: args.paymentReference ?? null,
      updatedAt: now,
    })
    .where(inArray(assignmentPayouts.id, args.payoutIds));

  return (updated as any).rowCount ?? args.payoutIds.length;
}
