import type { Express, Request, Response, NextFunction } from "express";
import { and, asc, desc, eq, gte, ilike, inArray, lte, or, sql } from "drizzle-orm";
import { db } from "./db";
import { bondAssignments, assignmentPayouts, investors } from "@shared/schema";
import { storage, logAudit } from "./storage";
import { addFrequency, markPayoutsPaid, upsertAssignmentFromSettlement, coerceDate } from "./services/assignmentService";

function getUserId(req: Request): string {
  const user = (req as any).user as any;
  return user?.claims?.sub;
}

async function requireInternalRole(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = getUserId(req);
    if (!userId) return res.status(401).json({ message: "Unauthorized" });

    const userSession = (req.session as any)?.user;
    if (userSession?.isAdmin === "true") return next();

    const role = await storage.getUserRole(userId);
    const allowed = new Set(["admin", "accounting", "ops", "investor_relations"]);
    if (!role?.role || !allowed.has(role.role)) {
      return res.status(403).json({ message: "Internal access required" });
    }
    return next();
  } catch (err) {
    console.error("Internal role check failed:", err);
    return res.status(500).json({ message: "Role check failed" });
  }
}

function parseCsvValue(v: any): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (s.includes(",") || s.includes("\n") || s.includes('"')) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

export function registerAssignmentRoutes(app: Express, isAuthenticated: any) {
  // List assignments with search + filters
  app.get("/api/admin/assignments", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const q = typeof req.query.q === "string" ? req.query.q.trim() : "";
      const status = typeof req.query.status === "string" ? req.query.status : undefined;
      const payoutFrequency = typeof req.query.payoutFrequency === "string" ? req.query.payoutFrequency : undefined;
      const investorId = typeof req.query.investorId === "string" ? req.query.investorId : undefined;
      const from = typeof req.query.from === "string" ? coerceDate(req.query.from) : null;
      const to = typeof req.query.to === "string" ? coerceDate(req.query.to) : null;
      const limit = typeof req.query.limit === "string" ? Math.min(parseInt(req.query.limit, 10) || 50, 200) : 100;

      const where: any[] = [];
      if (status) where.push(eq(bondAssignments.status, status as any));
      if (payoutFrequency) where.push(eq(bondAssignments.payoutFrequency, payoutFrequency as any));
      if (investorId) where.push(eq(bondAssignments.investorId, investorId));
      if (from) where.push(gte(bondAssignments.purchaseDate, from));
      if (to) where.push(lte(bondAssignments.purchaseDate, to));
      if (q) {
        const like = `%${q}%`;
        where.push(
          or(
            ilike(bondAssignments.bondName, like),
            ilike(bondAssignments.investorEmail, like),
            ilike(bondAssignments.investorName, like)
          )
        );
      }

      const rows = await db
        .select({
          id: bondAssignments.id,
          settlementSessionId: bondAssignments.settlementSessionId,
          tradeId: bondAssignments.tradeId,
          investorId: bondAssignments.investorId,
          investorEmail: bondAssignments.investorEmail,
          investorName: sql<string | null>`coalesce(${bondAssignments.investorName}, ${investors.firstName} || ' ' || ${investors.lastName}, ${investors.email})`,
          bondName: bondAssignments.bondName,
          purchaseAmount: bondAssignments.purchaseAmount,
          purchaseDate: bondAssignments.purchaseDate,
          payoutFrequency: bondAssignments.payoutFrequency,
          payoutStartDate: bondAssignments.payoutStartDate,
          payoutCount: bondAssignments.payoutCount,
          payoutAmount: bondAssignments.payoutAmount,
          status: bondAssignments.status,
          createdAt: bondAssignments.createdAt,
          updatedAt: bondAssignments.updatedAt,
          // Next payout date
          nextPayoutDate: sql<Date | null>`(
            select min(due_date)
            from assignment_payouts ap
            where ap.assignment_id = ${bondAssignments.id}
              and ap.status = 'scheduled'
          )`,
          nextPayoutStatus: sql<string | null>`(
            select ap.status
            from assignment_payouts ap
            where ap.assignment_id = ${bondAssignments.id}
            order by ap.due_date asc
            limit 1
          )`,
        })
        .from(bondAssignments)
        .leftJoin(investors, eq(investors.id, bondAssignments.investorId))
        .where(where.length ? and(...where) : undefined)
        .orderBy(desc(bondAssignments.purchaseDate))
        .limit(limit);

      res.json(rows);
    } catch (error) {
      console.error("Error fetching assignments:", error);
      res.status(500).json({ message: "Failed to fetch assignments" });
    }
  });

  // Create manual assignment
  app.post("/api/admin/assignments", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const userId = getUserId(req);
      const now = new Date();

      const purchaseAmount = Number(req.body?.purchaseAmount);
      if (!Number.isFinite(purchaseAmount) || purchaseAmount <= 0) {
        return res.status(400).json({ message: "purchaseAmount is required" });
      }

      const payoutStartDate = coerceDate(req.body?.payoutStartDate) ?? new Date(now.getTime() + 30 * 86400000);
      const payoutCount = Math.max(1, Number(req.body?.payoutCount ?? 12));
      const payoutAmount = Number(req.body?.payoutAmount ?? 0);

      const [assignment] = await db
        .insert(bondAssignments)
        .values({
          userId,
          settlementSessionId: req.body?.settlementSessionId ?? null,
          tradeId: req.body?.tradeId ?? null,
          investorId: req.body?.investorId ?? null,
          investorEmail: req.body?.investorEmail ?? null,
          investorName: req.body?.investorName ?? null,
          bondId: req.body?.bondId ?? null,
          bondName: req.body?.bondName ?? null,
          purchaseAmount: purchaseAmount.toFixed(2),
          purchaseDate: coerceDate(req.body?.purchaseDate) ?? now,
          payoutFrequency: req.body?.payoutFrequency ?? "monthly",
          payoutStartDate,
          payoutCount,
          payoutAmount: Number.isFinite(payoutAmount) ? payoutAmount.toFixed(2) : "0",
          status: req.body?.status ?? "active",
          notes: req.body?.notes ?? null,
          createdAt: now,
          updatedAt: now,
        } as any)
        .returning();

      // Generate payouts immediately
      // Generate scheduled payouts
      const freq = assignment.payoutFrequency as any;
      let cursor = new Date(assignment.payoutStartDate as any);
      const rows = [] as any[];
      for (let i = 0; i < assignment.payoutCount; i++) {
        rows.push({
          userId,
          assignmentId: assignment.id,
          dueDate: new Date(cursor),
          amount: assignment.payoutAmount,
          status: "scheduled",
          createdAt: now,
          updatedAt: now,
        });
        cursor = addFrequency(cursor, freq);
      }
      if (rows.length) await db.insert(assignmentPayouts).values(rows);

      await logAudit(userId, "create", "bond_assignment", assignment.id, "Created assignment", { assignmentId: assignment.id }, req.ip);

      res.status(201).json({ assignment });
    } catch (error) {
      console.error("Error creating assignment:", error);
      res.status(500).json({ message: "Failed to create assignment" });
    }
  });

  // Get assignment detail
  app.get("/api/admin/assignments/:id", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const id = req.params.id;
      const [assignment] = await db
        .select()
        .from(bondAssignments)
        .where(eq(bondAssignments.id, id))
        .limit(1);

      if (!assignment) return res.status(404).json({ message: "Assignment not found" });

      const [stats] = await db
        .select({
          total: sql<number>`count(*)`,
          scheduled: sql<number>`sum(case when ${assignmentPayouts.status} = 'scheduled' then 1 else 0 end)`,
          paid: sql<number>`sum(case when ${assignmentPayouts.status} = 'paid' then 1 else 0 end)`,
          cancelled: sql<number>`sum(case when ${assignmentPayouts.status} = 'cancelled' then 1 else 0 end)`,
          nextPayoutDate: sql<Date | null>`min(case when ${assignmentPayouts.status} = 'scheduled' then ${assignmentPayouts.dueDate} else null end)`,
        })
        .from(assignmentPayouts)
        .where(eq(assignmentPayouts.assignmentId, id));

      res.json({ assignment, stats });
    } catch (error) {
      console.error("Error fetching assignment:", error);
      res.status(500).json({ message: "Failed to fetch assignment" });
    }
  });

  // Update assignment (and optionally regenerate schedule)
  app.patch("/api/admin/assignments/:id", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const userId = getUserId(req);
      const id = req.params.id;
      const now = new Date();

      const [existing] = await db.select().from(bondAssignments).where(eq(bondAssignments.id, id)).limit(1);
      if (!existing) return res.status(404).json({ message: "Assignment not found" });

      const patch: any = {
        ...(req.body?.investorId !== undefined && { investorId: req.body.investorId }),
        ...(req.body?.investorEmail !== undefined && { investorEmail: req.body.investorEmail }),
        ...(req.body?.investorName !== undefined && { investorName: req.body.investorName }),
        ...(req.body?.bondName !== undefined && { bondName: req.body.bondName }),
        ...(req.body?.bondId !== undefined && { bondId: req.body.bondId }),
        ...(req.body?.purchaseAmount !== undefined && { purchaseAmount: Number(req.body.purchaseAmount).toFixed(2) }),
        ...(req.body?.purchaseDate !== undefined && { purchaseDate: coerceDate(req.body.purchaseDate) ?? existing.purchaseDate }),
        ...(req.body?.payoutFrequency !== undefined && { payoutFrequency: req.body.payoutFrequency }),
        ...(req.body?.payoutStartDate !== undefined && { payoutStartDate: coerceDate(req.body.payoutStartDate) ?? existing.payoutStartDate }),
        ...(req.body?.payoutCount !== undefined && { payoutCount: Math.max(1, Number(req.body.payoutCount)) }),
        ...(req.body?.payoutAmount !== undefined && { payoutAmount: Number(req.body.payoutAmount).toFixed(2) }),
        ...(req.body?.status !== undefined && { status: req.body.status }),
        ...(req.body?.notes !== undefined && { notes: req.body.notes }),
        updatedAt: now,
      };

      const [updated] = await db.update(bondAssignments).set(patch).where(eq(bondAssignments.id, id)).returning();

      const regenerate = Boolean(req.body?.regeneratePayouts);
      if (regenerate) {
        // Keep PAID payouts, remove scheduled/cancelled and regenerate
        await db
          .delete(assignmentPayouts)
          .where(and(eq(assignmentPayouts.assignmentId, id), inArray(assignmentPayouts.status, ["scheduled", "cancelled"] as any)));

        const { addFrequency } = await import("./services/assignmentService");
        let cursor = new Date(updated.payoutStartDate as any);
        const rows: any[] = [];
        for (let i = 0; i < updated.payoutCount; i++) {
          rows.push({
            userId,
            assignmentId: id,
            dueDate: new Date(cursor),
            amount: updated.payoutAmount,
            status: "scheduled",
            createdAt: now,
            updatedAt: now,
          });
          cursor = addFrequency(cursor, updated.payoutFrequency as any);
        }
        if (rows.length) await db.insert(assignmentPayouts).values(rows);
      }

      await logAudit(userId, "update", "bond_assignment", id, "Updated assignment", { assignmentId: id }, req.ip);

      res.json({ assignment: updated, regenerated: regenerate });
    } catch (error) {
      console.error("Error updating assignment:", error);
      res.status(500).json({ message: "Failed to update assignment" });
    }
  });

  // List payouts for an assignment
  app.get("/api/admin/assignments/:id/payouts", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const id = req.params.id;
      const status = typeof req.query.status === "string" ? req.query.status : undefined; // scheduled|paid|cancelled|all
      const where: any[] = [eq(assignmentPayouts.assignmentId, id)];
      if (status && status !== "all") where.push(eq(assignmentPayouts.status, status as any));

      const rows = await db
        .select()
        .from(assignmentPayouts)
        .where(and(...where))
        .orderBy(asc(assignmentPayouts.dueDate));

      res.json(rows);
    } catch (error) {
      console.error("Error fetching assignment payouts:", error);
      res.status(500).json({ message: "Failed to fetch payouts" });
    }
  });

  // Batch mark paid
  app.post("/api/admin/assignments/:id/payouts/mark-paid", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const userId = getUserId(req);
      const payoutIds = Array.isArray(req.body?.payoutIds) ? (req.body.payoutIds as string[]) : [];
      const paymentReference = typeof req.body?.paymentReference === "string" ? req.body.paymentReference : null;
      const paidAt = coerceDate(req.body?.paidAt) ?? new Date();

      const updatedCount = await markPayoutsPaid({ ownerUserId: userId, payoutIds, paymentReference, paidAt });

      await logAudit(userId, "update", "assignment_payout", req.params.id, `Marked ${updatedCount} payouts paid`, { payoutIds }, req.ip);

      res.json({ success: true, updatedCount });
    } catch (error) {
      console.error("Error marking payouts paid:", error);
      res.status(500).json({ message: "Failed to mark payouts paid" });
    }
  });

  // Global batch mark paid (across assignments) — used by Calendar → Payouts tab
  app.post("/api/admin/payouts/mark-paid", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const userId = getUserId(req);
      const payoutIds = Array.isArray(req.body?.payoutIds) ? (req.body.payoutIds as string[]) : [];
      const paymentReference = typeof req.body?.paymentReference === "string" ? req.body.paymentReference : null;
      const paidAt = coerceDate(req.body?.paidAt) ?? new Date();

      const updatedCount = await markPayoutsPaid({ ownerUserId: userId, payoutIds, paymentReference, paidAt });

      await logAudit(userId, "update", "assignment_payout", "bulk", `Marked ${updatedCount} payouts paid (global)`, { payoutIds }, req.ip);

      res.json({ success: true, updatedCount });
    } catch (error) {
      console.error("Error marking payouts paid (global):", error);
      res.status(500).json({ message: "Failed to mark payouts paid" });
    }
  });

  // Calendar feed - payouts (scheduled/paid/cancelled)
  app.get("/api/admin/payouts", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const from = typeof req.query.from === "string" ? coerceDate(req.query.from) : null;
      const to = typeof req.query.to === "string" ? coerceDate(req.query.to) : null;
      const statuses = typeof req.query.statuses === "string" ? req.query.statuses.split(",").map((s) => s.trim()).filter(Boolean) : ["scheduled", "paid", "cancelled"];
      const where: any[] = [];
      if (from) where.push(gte(assignmentPayouts.dueDate, from));
      if (to) where.push(lte(assignmentPayouts.dueDate, to));
      if (statuses.length) where.push(inArray(assignmentPayouts.status, statuses as any));

      const rows = await db
        .select({
          payoutId: assignmentPayouts.id,
          assignmentId: assignmentPayouts.assignmentId,
          dueDate: assignmentPayouts.dueDate,
          amount: assignmentPayouts.amount,
          status: assignmentPayouts.status,
          paidAt: assignmentPayouts.paidAt,
          investorName: sql<string | null>`coalesce(${bondAssignments.investorName}, ${investors.firstName} || ' ' || ${investors.lastName}, ${bondAssignments.investorEmail})`,
          investorEmail: bondAssignments.investorEmail,
          bondName: bondAssignments.bondName,
          tradeId: bondAssignments.tradeId,
        })
        .from(assignmentPayouts)
        .innerJoin(bondAssignments, eq(bondAssignments.id, assignmentPayouts.assignmentId))
        .leftJoin(investors, eq(investors.id, bondAssignments.investorId))
        .where(where.length ? and(...where) : undefined)
        .orderBy(asc(assignmentPayouts.dueDate))
        .limit(500);

      res.json(rows);
    } catch (error) {
      console.error("Error fetching payout feed:", error);
      res.status(500).json({ message: "Failed to fetch payout feed" });
    }
  });

  // Export payouts to CSV (includes scheduled + paid + cancelled)
  app.get("/api/admin/payouts/export.csv", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const from = typeof req.query.from === "string" ? coerceDate(req.query.from) : null;
      const to = typeof req.query.to === "string" ? coerceDate(req.query.to) : null;
      const statuses = typeof req.query.statuses === "string" ? req.query.statuses.split(",").map((s) => s.trim()).filter(Boolean) : ["scheduled", "paid", "cancelled"];

      const where: any[] = [];
      if (from) where.push(gte(assignmentPayouts.dueDate, from));
      if (to) where.push(lte(assignmentPayouts.dueDate, to));
      if (statuses.length) where.push(inArray(assignmentPayouts.status, statuses as any));

      const rows = await db
        .select({
          payoutId: assignmentPayouts.id,
          assignmentId: assignmentPayouts.assignmentId,
          dueDate: assignmentPayouts.dueDate,
          amount: assignmentPayouts.amount,
          status: assignmentPayouts.status,
          paidAt: assignmentPayouts.paidAt,
          paymentReference: assignmentPayouts.paymentReference,
          investorName: sql<string | null>`coalesce(${bondAssignments.investorName}, ${investors.firstName} || ' ' || ${investors.lastName}, ${bondAssignments.investorEmail})`,
          investorEmail: bondAssignments.investorEmail,
          bondName: bondAssignments.bondName,
          tradeId: bondAssignments.tradeId,
          settlementSessionId: bondAssignments.settlementSessionId,
        })
        .from(assignmentPayouts)
        .innerJoin(bondAssignments, eq(bondAssignments.id, assignmentPayouts.assignmentId))
        .leftJoin(investors, eq(investors.id, bondAssignments.investorId))
        .where(where.length ? and(...where) : undefined)
        .orderBy(asc(assignmentPayouts.dueDate))
        .limit(5000);

      const header = [
        "payoutId",
        "assignmentId",
        "dueDate",
        "amount",
        "status",
        "paidAt",
        "paymentReference",
        "investorName",
        "investorEmail",
        "bondName",
        "tradeId",
        "settlementSessionId",
      ].join(",");

      const lines = rows.map((r) =>
        [
          r.payoutId,
          r.assignmentId,
          r.dueDate ? new Date(r.dueDate as any).toISOString() : "",
          r.amount,
          r.status,
          r.paidAt ? new Date(r.paidAt as any).toISOString() : "",
          r.paymentReference,
          r.investorName,
          r.investorEmail,
          r.bondName,
          r.tradeId,
          r.settlementSessionId,
        ]
          .map(parseCsvValue)
          .join(",")
      );

      const csv = [header, ...lines].join("\n");
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename=\"payouts-export.csv\"`);
      res.send(csv);
    } catch (error) {
      console.error("Error exporting payouts:", error);
      res.status(500).json({ message: "Failed to export payouts" });
    }
  });

  // Export payouts for an assignment
  app.get("/api/admin/assignments/:id/payouts/export.csv", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const id = req.params.id;
      const statuses = typeof req.query.statuses === "string" ? req.query.statuses.split(",").map((s) => s.trim()).filter(Boolean) : ["scheduled", "paid", "cancelled"];

      const where: any[] = [eq(assignmentPayouts.assignmentId, id)];
      if (statuses.length) where.push(inArray(assignmentPayouts.status, statuses as any));

      const rows = await db
        .select({
          payoutId: assignmentPayouts.id,
          dueDate: assignmentPayouts.dueDate,
          amount: assignmentPayouts.amount,
          status: assignmentPayouts.status,
          paidAt: assignmentPayouts.paidAt,
          paymentReference: assignmentPayouts.paymentReference,
          notes: assignmentPayouts.notes,
        })
        .from(assignmentPayouts)
        .where(and(...where))
        .orderBy(asc(assignmentPayouts.dueDate));

      const header = ["payoutId", "dueDate", "amount", "status", "paidAt", "paymentReference", "notes"].join(",");
      const lines = rows.map((r) =>
        [
          r.payoutId,
          r.dueDate ? new Date(r.dueDate as any).toISOString() : "",
          r.amount,
          r.status,
          r.paidAt ? new Date(r.paidAt as any).toISOString() : "",
          r.paymentReference,
          r.notes,
        ]
          .map(parseCsvValue)
          .join(",")
      );

      const csv = [header, ...lines].join("\n");
      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename=\"assignment-${id}-payouts.csv\"`);
      res.send(csv);
    } catch (error) {
      console.error("Error exporting assignment payouts:", error);
      res.status(500).json({ message: "Failed to export payouts" });
    }
  });

  // Sync assignment from settlement session (used by Settlement Inbox Quick Add)
  app.post("/api/admin/settlements/:sessionId/sync-assignment", isAuthenticated, requireInternalRole, async (req, res) => {
    try {
      const userId = getUserId(req);
      const sessionId = req.params.sessionId;
      const overrides = typeof req.body?.assignment === "object" && req.body.assignment ? req.body.assignment : {};

      const result = await upsertAssignmentFromSettlement({ ownerUserId: userId, sessionId, overrides });

      await logAudit(
        userId,
        "update",
        "bond_assignment",
        result.assignment.id,
        "Synced assignment from settlement session",
        {
          sessionId,
          assignmentId: result.assignment.id,
          created: result.created,
          payoutsGenerated: result.payoutsGenerated,
        },
        req.ip
      );

      res.json({
        success: true,
        assignment: result.assignment,
        created: result.created,
        payoutsGenerated: result.payoutsGenerated,
      });
    } catch (error) {
      console.error("Error syncing assignment:", error);
      res.status(500).json({ message: "Failed to sync assignment" });
    }
  });
}
