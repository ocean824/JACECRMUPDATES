#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"

ran=0

if [ -d "apps/api" ]; then
  bash "$ROOT/apply_voice_agent_patch.sh"
  ran=1
fi

if [ -d "client/src" ]; then
  bash "$ROOT/apply_jace_crm_patch.sh"
  ran=1
fi

if [ "$ran" -eq 0 ]; then
  echo "ERROR: Run this from either the VOICE AGENT repo root (apps/api) or the JACE CRM repo root (client/src)." >&2
  exit 1
fi
