# postMessage Bridge Patch (JACE ↔ Voice Agent)

This patch adds a **safe postMessage bridge** so the JACE external onboarding page can pass **non-sensitive context** into the embedded voice agent:

- `firstName`
- `email`
- `progress` (0–100)

**It does NOT send the onboarding token.**

It also makes the voice agent store that context per-session (SQLite), so it remains available across turns and across embeddings (CRM + onboarding) as long as the session ID is the same.

---

## What you get

### JACE CRM changes
- `client/src/components/VoiceAssistantWidget.tsx`
  - Adds iframe handshake and `postMessage` context push.
  - Uses strict `targetOrigin` (voice agent origin).
- `client/src/pages/external-onboarding.tsx`
  - Computes `voiceContext` `{ firstName, email, progress, page }` and passes it into the widget.

### Voice Agent changes
- `apps/api/public/agent.js`
  - Accepts `parentOrigin` query param.
  - Sends `VOICE_AGENT_READY` to parent.
  - Receives `VOICE_AGENT_CONTEXT` and POSTs it to the server.
- `apps/api/src/routes/voiceAgent.ts`
  - Adds `POST /api/voice/context` to persist context.
- `apps/api/src/voice/db.ts` + `apps/api/src/voice/memory.ts`
  - Adds `session_context` table and get/set helpers.
- `apps/api/src/voice/llm.ts`
  - Injects stored session context into the system context.
- `apps/api/src/index.ts`
  - Fixes duplicated/malformed middleware from prior bundle.

---

## How to apply (Replit)

### A) Apply to Voice Agent Replit
1. Open your **voice agent** Replit.
2. Upload this ZIP.
3. Open the Replit Shell and run:

```bash
bash apply_voice_agent_patch.sh
```

4. Set Replit Secrets:
- `EMBED_ALLOWED_ORIGINS=https://jace-enterprise-crm.replit.app`

Restart.

### B) Apply to JACE CRM Replit
1. Open your **JACE CRM** Replit.
2. Upload this ZIP.
3. Open the Replit Shell and run:

```bash
bash apply_jace_crm_patch.sh
```

4. Set/confirm in Replit Secrets (JACE CRM):
- `VITE_VOICE_AGENT_URL=https://<YOUR-VOICE-AGENT-REPLIT>.replit.app`

Restart.

---

## How it works (protocol)

1. JACE loads voice agent iframe:
   - `/agent?embed=1&parentOrigin=<JACE_ORIGIN>`
2. Voice agent posts:
   - `{ type: "VOICE_AGENT_READY" }`
3. JACE responds:
   - `{ type: "VOICE_AGENT_CONTEXT", payload: { firstName, email, progress, page } }`
4. Voice agent persists context to:
   - `POST /api/voice/context`

---

## Troubleshooting

- If the iframe never loads, confirm the voice-agent repl has:
  - `EMBED_ALLOWED_ORIGINS` set to the JACE origin.
- If messages are ignored, confirm:
  - `VITE_VOICE_AGENT_URL` is correct
  - the origins match exactly (no trailing slash)

