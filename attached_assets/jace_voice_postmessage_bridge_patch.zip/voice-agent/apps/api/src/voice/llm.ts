import fs from "node:fs";
import path from "node:path";

import { getOpenAI } from "./openaiClient";
import { findRelevantMemories, getRecentTurns, getSessionContext, getSummary } from "./memory";

function loadSystemPrompt(): string {
  const p = path.resolve("prompts/agent_system.md");
  return fs.readFileSync(p, "utf8");
}

function applyTemplate(s: string): string {
  return s
    .replaceAll("{{AGENT_NAME}}", process.env.AGENT_NAME || "Amelia")
    .replaceAll("{{AGENT_LOCALE}}", process.env.AGENT_LOCALE || "en-GB");
}

export async function generateAssistantReply(args: {
  sessionId: string;
  userText: string;
  clientIp?: string;
  client?: { timezone?: string; url?: string; userAgent?: string };
}): Promise<string> {
  if (!process.env.OPENAI_API_KEY) {
    // Degraded mode: echo-style assistant.
    return "I’m running without an LLM key right now. Please add OPENAI_API_KEY, then try again.";
  }

  const openai = getOpenAI();
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";

  const baseSystem = applyTemplate(loadSystemPrompt());
  const styleHint = (process.env.AGENT_STYLE_HINT || "").trim();

  const summary = await getSummary(args.sessionId);
  const sessionContext = await getSessionContext(args.sessionId);
  const memories = await findRelevantMemories({
    sessionId: args.sessionId,
    query: args.userText,
    topK: Number(process.env.MEMORY_TOP_K || 6)
  });

  const recent = await getRecentTurns(args.sessionId);

  const memoryBlockLines: string[] = [];
  if (styleHint) memoryBlockLines.push(`Voice style hint: ${styleHint}`);
  if (args.client?.timezone) memoryBlockLines.push(`User timezone: ${args.client.timezone}`);
  if (args.client?.url) memoryBlockLines.push(`User page: ${args.client.url}`);
  if (args.clientIp) memoryBlockLines.push(`User IP: ${args.clientIp}`);
  if (sessionContext) {
    const safeKeys = Object.keys(sessionContext);
    if (safeKeys.length) {
      memoryBlockLines.push("Embedding context (non-sensitive):");
      for (const k of safeKeys) {
        const v = (sessionContext as any)[k];
        if (v === undefined || v === null) continue;
        memoryBlockLines.push(`- ${k}: ${typeof v === "string" ? v : JSON.stringify(v)}`);
      }
    }
  }
  if (summary) memoryBlockLines.push(`Conversation summary: ${summary}`);
  if (memories.length) {
    memoryBlockLines.push("Relevant user context:");
    for (const m of memories) memoryBlockLines.push(`- ${m}`);
  }

  const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [];
  messages.push({ role: "system", content: baseSystem });
  if (memoryBlockLines.length) {
    messages.push({ role: "system", content: memoryBlockLines.join("\n") });
  }

  // Include last turns (already includes the latest user message because we stored it before calling this fn)
  for (const t of recent) {
    messages.push({ role: t.role, content: t.text });
  }

  // Ensure the current user message is present at end (avoid duplicate if recent already ends with same)
  const last = messages[messages.length - 1];
  if (!last || last.role !== "user" || last.content.trim() !== args.userText.trim()) {
    messages.push({ role: "user", content: args.userText });
  }

  const out = await openai.chat.completions.create({
    model,
    temperature: 0.4,
    messages
  });

  return (out.choices?.[0]?.message?.content || "").trim() || "Sorry, I didn’t catch that.";
}
