import crypto from "node:crypto";

import { getDb } from "./db";
import { embedText, cosineSimilarity } from "./similarity";

export type TurnRole = "user" | "assistant";

export async function createSession(): Promise<string> {
  const db = await getDb();
  const id = crypto.randomUUID();
  await db.run("INSERT INTO sessions (id, created_at) VALUES (?, ?)", [id, Date.now()]);
  return id;
}

export async function storeTurn(sessionId: string, role: TurnRole, text: string): Promise<void> {
  const db = await getDb();
  await db.run(
    "INSERT INTO turns (session_id, role, text, created_at) VALUES (?, ?, ?, ?)",
    [sessionId, role, text, Date.now()]
  );
}

export async function getRecentTurns(sessionId: string): Promise<Array<{ role: TurnRole; text: string; created_at: number }>> {
  const db = await getDb();
  const max = Number(process.env.MEMORY_MAX_RECENT_TURNS || 12);
  const rows = await db.all(
    "SELECT role, text, created_at FROM turns WHERE session_id = ? ORDER BY created_at DESC LIMIT ?",
    [sessionId, max]
  );
  return rows.reverse();
}

export async function getSummary(sessionId: string): Promise<string | null> {
  const db = await getDb();
  const row = await db.get("SELECT summary FROM summaries WHERE session_id = ?", [sessionId]);
  return row?.summary || null;
}

export type SessionContext = {
  firstName?: string;
  email?: string;
  progress?: number;
  page?: string;
  [key: string]: unknown;
};

export async function setSessionContext(sessionId: string, context: SessionContext): Promise<void> {
  const db = await getDb();
  const cleaned: SessionContext = {};
  if (context && typeof context === "object") {
    for (const [k, v] of Object.entries(context)) {
      if (v === undefined) continue;
      cleaned[k] = v;
    }
  }

  await db.run(
    `INSERT INTO session_context (session_id, context_json, updated_at)
     VALUES (?, ?, ?)
     ON CONFLICT(session_id) DO UPDATE SET context_json = excluded.context_json, updated_at = excluded.updated_at`,
    [sessionId, JSON.stringify(cleaned), Date.now()]
  );
}

export async function getSessionContext(sessionId: string): Promise<SessionContext | null> {
  const db = await getDb();
  const row = await db.get("SELECT context_json FROM session_context WHERE session_id = ?", [sessionId]);
  if (!row?.context_json) return null;
  try {
    const parsed = JSON.parse(String(row.context_json));
    if (parsed && typeof parsed === "object") return parsed as SessionContext;
    return null;
  } catch {
    return null;
  }
}

export async function addMemory(args: { sessionId?: string; content: string; importance?: number }): Promise<void> {
  const db = await getDb();
  const importance = args.importance ?? 1;
  const embedding = await embedText(args.content);
  await db.run(
    "INSERT INTO memories (session_id, content, embedding_json, importance, created_at) VALUES (?, ?, ?, ?, ?)",
    [args.sessionId || null, args.content, embedding ? JSON.stringify(embedding) : null, importance, Date.now()]
  );
}

export async function findRelevantMemories(args: { sessionId: string; query: string; topK?: number }): Promise<string[]> {
  const db = await getDb();
  const topK = args.topK ?? Number(process.env.MEMORY_TOP_K || 6);

  const queryEmbedding = await embedText(args.query);
  if (queryEmbedding) {
    // Pull a reasonable candidate set and rank in-process (SQLite lacks native vector ops here).
    const candidates = await db.all(
      "SELECT content, embedding_json, importance FROM memories WHERE session_id IS NULL OR session_id = ? ORDER BY created_at DESC LIMIT 200",
      [args.sessionId]
    );

    const scored = candidates
      .map((c: any) => {
        const emb = c.embedding_json ? (JSON.parse(c.embedding_json) as number[]) : null;
        const sim = emb ? cosineSimilarity(queryEmbedding, emb) : 0;
        const boost = 1 + Math.min(3, Number(c.importance || 1)) * 0.05;
        return { content: String(c.content), score: sim * boost };
      })
      .sort((a: any, b: any) => b.score - a.score)
      .slice(0, topK)
      .filter((x: any) => x.score > 0.15);

    return scored.map((s: any) => s.content);
  }

  // Fallback: naive keyword match
  const tokens = args.query
    .toLowerCase()
    .split(/\W+/)
    .filter((t) => t.length >= 4)
    .slice(0, 8);
  if (tokens.length === 0) return [];

  const like = tokens.map(() => "content LIKE ?").join(" OR ");
  const params = tokens.map((t) => `%${t}%`);

  const rows = await db.all(
    `SELECT content FROM memories WHERE (session_id IS NULL OR session_id = ?) AND (${like}) ORDER BY importance DESC, created_at DESC LIMIT ?`,
    [args.sessionId, ...params, topK]
  );
  return rows.map((r: any) => String(r.content));
}

