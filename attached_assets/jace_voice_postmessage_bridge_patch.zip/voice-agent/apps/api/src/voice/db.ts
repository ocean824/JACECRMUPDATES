import fs from "node:fs";
import path from "node:path";

import sqlite3 from "sqlite3";
import { open, type Database } from "sqlite";

let dbPromise: Promise<Database> | null = null;

function resolveDbPath(): string {
  const p = process.env.MEMORY_DB_PATH || "./data/agent.sqlite";
  return path.resolve(p);
}

async function migrate(db: Database): Promise<void> {
  await db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS turns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      role TEXT NOT NULL,
      text TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY(session_id) REFERENCES sessions(id)
    );

    CREATE TABLE IF NOT EXISTS memories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT,
      content TEXT NOT NULL,
      embedding_json TEXT,
      importance INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS summaries (
      session_id TEXT PRIMARY KEY,
      summary TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );

    -- Non-sensitive per-session context passed from an embedding parent page (e.g. first name, email, progress %).
    -- This is intentionally separated from turns so it doesn't pollute the conversation log.
    CREATE TABLE IF NOT EXISTS session_context (
      session_id TEXT PRIMARY KEY,
      context_json TEXT NOT NULL,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY(session_id) REFERENCES sessions(id)
    );
  `);

  await db.exec(`
    CREATE INDEX IF NOT EXISTS idx_turns_session_created ON turns(session_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_memories_session_created ON memories(session_id, created_at);
  `);
}

export async function getDb(): Promise<Database> {
  if (!dbPromise) {
    const dbPath = resolveDbPath();
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    dbPromise = (async () => {
      const db = await open({ filename: dbPath, driver: sqlite3.Database });
      await migrate(db);
      return db;
    })();
  }
  return dbPromise;
}
