import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import path from "node:path";
import fs from "node:fs";

import publicIntake from "./routes/publicIntake";
import contract from "./routes/contract";
import payments from "./routes/payments";
import webhooks from "./routes/webhooks";
import skills from "./routes/skills";
import voiceAgent from "./routes/voiceAgent";

dotenv.config();

const app = express();

// Allow safe iframe embedding (for JACE CRM / onboarding pages).
// Set EMBED_ALLOWED_ORIGINS in Replit Secrets, comma-separated, e.g.
// EMBED_ALLOWED_ORIGINS="https://jace-enterprise-crm.replit.app"
app.use((req, res, next) => {
  const raw = (process.env.EMBED_ALLOWED_ORIGINS || "").trim();
  if (raw) {
    const allowed = raw
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    if (allowed.length) {
      const frameAncestors = ["'self'", ...allowed].join(" ");
      const inject = `frame-ancestors ${frameAncestors}`;

      const existing = res.getHeader("Content-Security-Policy");
      if (typeof existing === "string" && existing.trim()) {
        const cleaned = existing
          .replace(/frame-ancestors[^;]*;?/g, "")
          .trim()
          .replace(/;\s*$/, "");
        res.setHeader("Content-Security-Policy", (cleaned ? cleaned + "; " : "") + inject);
      } else {
        res.setHeader("Content-Security-Policy", inject);
      }
    }
  }

  // Let the iframe request the microphone (browser may still prompt user).
  const ppExisting = res.getHeader("Permissions-Policy");
  if (!ppExisting) res.setHeader("Permissions-Policy", "microphone=(self)");

  next();
});

// Trust proxy so req.ip is correct behind Nginx / Cloudflare
if (process.env.TRUST_PROXY === "true") app.set("trust proxy", true);

app.use(
  cors({
    origin: true,
    credentials: true
  })
);

// JSON parsing with raw-body capture for Stripe webhook verification
app.use(
  express.json({
    limit: "10mb",
    verify: (req, _res, buf) => {
      // Stripe requires the *raw* request body to verify signatures
      (req as any).rawBody = buf;
    }
  })
);

// Capture client ip for signature stamping / audit
app.use((req, _res, next) => {
  (req as any).clientIp = req.ip;
  next();
});

app.get("/healthz", (_req, res) => res.json({ ok: true }));

// Serve widget + static assets
const pubDir = path.resolve("public");
app.use(express.static(pubDir));
app.get("/intake-widget", (_req, res) => {
  res.sendFile(path.join(pubDir, "intake-widget.html"));
});

// Voice chat UI (embed-friendly)
app.get(["/agent", "/"], (_req, res) => {
  res.sendFile(path.join(pubDir, "agent.html"));
});

// Serve generated artifacts (PDFs + audio)
// Backward compatible PDF route
app.get("/files/:filename", (req, res) => {
  const filename = req.params.filename;
  const dataRoot = path.resolve(process.env.DATA_DIR || "./data");
  const full = path.join(dataRoot, "files", filename);
  if (!fs.existsSync(full)) return res.status(404).send("not found");
  res.setHeader("Content-Type", "application/pdf");
  fs.createReadStream(full).pipe(res);
});

app.get("/files/:kind/:filename", (req, res) => {
  const kind = req.params.kind;
  const filename = req.params.filename;
  const dataRoot = path.resolve(process.env.DATA_DIR || "./data");
  const full = path.join(dataRoot, kind, filename);
  if (!fs.existsSync(full)) return res.status(404).send("not found");

  if (kind === "pdf") res.setHeader("Content-Type", "application/pdf");
  else if (kind === "audio") res.setHeader("Content-Type", "audio/mpeg");
  else res.setHeader("Content-Type", "application/octet-stream");

  fs.createReadStream(full).pipe(res);
});

// API routes
app.use("/api/public/intake", publicIntake);
app.use("/api/public/contract", contract);
app.use("/api/public/payments", payments);
app.use("/api/webhooks", webhooks);
app.use("/api/skills", skills);
app.use("/api/voice", voiceAgent);

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`API running on :${port}`));
