import express from "express";
import multer from "multer";
import { z } from "zod";

import { createSession, getRecentTurns, setSessionContext, storeTurn } from "../voice/memory";
import { postProcessTurnPair } from "../voice/memoryPostProcess";
import { transcribeAudio } from "../voice/stt";
import { generateAssistantReply } from "../voice/llm";
import { synthesizeSpeechToFile } from "../voice/tts";

const router = express.Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 }
});

router.post("/session", async (_req, res) => {
  const sessionId = await createSession();
  res.json({ sessionId });
});

router.get("/session/:sessionId/recent", async (req, res) => {
  const turns = await getRecentTurns(req.params.sessionId);
  res.json({ turns });
});

// Non-sensitive host-app context injection (e.g., first name, email, onboarding progress%).
// This is used when the agent is embedded in another app (like JACE CRM) and needs
// extra grounding without ever receiving the onboarding token.
router.post("/context", async (req, res) => {
  const schema = z.object({
    sessionId: z.string().min(1),
    context: z
      .object({
        firstName: z.string().optional(),
        email: z.string().optional(),
        progress: z.number().min(0).max(100).optional(),
        page: z.string().optional()
      })
      .passthrough()
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Bad request" });

  try {
    await setSessionContext(parsed.data.sessionId, parsed.data.context);
    res.json({ ok: true });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Failed to store context" });
  }
});

router.post("/transcribe", upload.single("audio"), async (req, res) => {
  const sessionId = String(req.body.sessionId || "").trim();
  if (!sessionId) return res.status(400).json({ error: "Missing sessionId" });
  if (!req.file) return res.status(400).json({ error: "Missing audio" });

  try {
    const text = await transcribeAudio({
      audio: req.file.buffer,
      mimeType: req.file.mimetype || "application/octet-stream",
      filename: req.file.originalname || "audio.webm"
    });
    res.json({ text });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Transcription failed" });
  }
});

router.post("/message", async (req, res) => {
  const schema = z.object({
    sessionId: z.string().min(1),
    userText: z.string().min(1),
    client: z
      .object({
        timezone: z.string().optional(),
        url: z.string().optional(),
        userAgent: z.string().optional()
      })
      .passthrough()
      .optional()
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Bad request" });

  const { sessionId, userText, client } = parsed.data;

  try {
    await storeTurn(sessionId, "user", userText);

    const replyText = await generateAssistantReply({
      sessionId,
      userText,
      clientIp: req.ip,
      client
    });

    await storeTurn(sessionId, "assistant", replyText);

    // Store longer-term memories + summary (best-effort)
    postProcessTurnPair({ sessionId, userText, assistantText: replyText }).catch(() => {});

    const audioFilename = await synthesizeSpeechToFile({
      text: replyText,
      sessionId
    });

    res.json({
      assistantText: replyText,
      audioUrl: audioFilename ? `/files/audio/${audioFilename}` : null
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || "Chat failed" });
  }
});

export default router;
