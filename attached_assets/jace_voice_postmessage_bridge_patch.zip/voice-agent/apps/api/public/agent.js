(() => {
  const qs = new URLSearchParams(location.search);
  const isEmbed = qs.get("embed") === "1";
  const parentOrigin = (qs.get("parentOrigin") || "").trim();

  const el = {
    chat: document.getElementById("chat"),
    ptt: document.getElementById("ptt"),
    stopAudio: document.getElementById("stopAudio"),
    textInput: document.getElementById("textInput"),
    sendText: document.getElementById("sendText"),
    useBrowserSpeech: document.getElementById("useBrowserSpeech"),
    resetSession: document.getElementById("resetSession")
  };

  let sessionId = null;
  let mediaRecorder = null;
  let chunks = [];
  let currentAudio = null;
  let recognition = null;
  let hostContext = null;

  function now() {
    return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function addMessage(role, text) {
    const msg = document.createElement("div");
    msg.className = "msg";
    const bubble = document.createElement("div");
    bubble.className = "bubble " + role;
    bubble.textContent = text;
    const meta = document.createElement("div");
    meta.className = "meta";
    meta.textContent = `${role === "user" ? "You" : "Agent"} • ${now()}`;
    const wrap = document.createElement("div");
    wrap.appendChild(bubble);
    wrap.appendChild(meta);
    msg.appendChild(wrap);
    el.chat.appendChild(msg);
    el.chat.scrollTop = el.chat.scrollHeight;
  }

  async function api(path, opts) {
    const r = await fetch(path, opts);
    if (!r.ok) {
      const msg = await r.text().catch(() => "");
      throw new Error(msg || `Request failed (${r.status})`);
    }
    return r;
  }

  async function ensureSession(forceNew = false) {
    if (!forceNew) {
      const stored = localStorage.getItem("voice_agent_session");
      if (stored) {
        sessionId = stored;
        return;
      }
    }
    const r = await api("/api/voice/session", { method: "POST" });
    const j = await r.json();
    sessionId = j.sessionId;
    localStorage.setItem("voice_agent_session", sessionId);
  }

  async function ingestHostContext(context) {
    if (!context || typeof context !== "object") return;
    hostContext = context;
    await ensureSession();
    try {
      await api("/api/voice/context", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId, context })
      });
    } catch {
      // best-effort
    }
  }

  function stopPlayback() {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      currentAudio = null;
    }
  }

  async function playAudioUrl(url) {
    stopPlayback();
    if (!url) return;
    const audio = new Audio(url);
    currentAudio = audio;
    await audio.play();
  }

  async function sendText(text) {
    const trimmed = String(text || "").trim();
    if (!trimmed) return;
    await ensureSession();
    addMessage("user", trimmed);

    const payload = {
      sessionId,
      userText: trimmed,
      client: {
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        url: location.href,
        userAgent: navigator.userAgent,
        hostContext: hostContext || undefined
      }
    };

    const r = await api("/api/voice/message", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const j = await r.json();
    addMessage("assistant", j.assistantText || "");

    if (el.useBrowserSpeech.checked) {
      speakBrowser(j.assistantText || "");
    } else {
      await playAudioUrl(j.audioUrl);
    }
  }

  // ---------- Browser Speech fallback ----------
  function setupSpeechRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return null;
    const rec = new SpeechRecognition();
    rec.lang = "en-GB";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    return rec;
  }

  function speakBrowser(text) {
    if (!text) return;
    const synth = window.speechSynthesis;
    if (!synth) return;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-GB";
    const pick = (synth.getVoices() || []).find(v => /en-GB/i.test(v.lang) && /female|woman/i.test(v.name))
      || (synth.getVoices() || []).find(v => /en-GB/i.test(v.lang))
      || null;
    if (pick) u.voice = pick;
    synth.speak(u);
  }

  async function recordWithMediaRecorder() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus" : "audio/webm";
    mediaRecorder = new MediaRecorder(stream, { mimeType: mime });
    chunks = [];
    mediaRecorder.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
    return new Promise((resolve) => {
      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(chunks, { type: mime });
        resolve(blob);
      };
      mediaRecorder.start();
    });
  }

  async function stopRecordingAndTranscribe(blobPromise) {
    if (!mediaRecorder) return;
    mediaRecorder.stop();
    const blob = await blobPromise;
    const form = new FormData();
    form.append("sessionId", sessionId);
    form.append("audio", blob, "speech.webm");

    const r = await api("/api/voice/transcribe", { method: "POST", body: form });
    const j = await r.json();
    return (j.text || "").trim();
  }

  // ---------- Event wiring ----------
  let recordingBlobPromise = null;

  async function onPressStart() {
    stopPlayback();
    await ensureSession();
    el.ptt.classList.add("recording");
    el.ptt.textContent = "Recording… release to send";

    if (el.useBrowserSpeech.checked) {
      recognition = recognition || setupSpeechRecognition();
      if (!recognition) {
        addMessage("assistant", "Your browser does not support SpeechRecognition. Uncheck 'Use browser speech' or try Chrome.");
        el.useBrowserSpeech.checked = false;
        return;
      }
      return new Promise((resolve) => {
        recognition.onresult = async (evt) => {
          const text = evt.results?.[0]?.[0]?.transcript || "";
          resolve(String(text).trim());
        };
        recognition.onerror = () => resolve("");
        recognition.onend = () => {};
        recognition.start();
      }).then((text) => {
        if (text) sendText(text).catch(err => addMessage("assistant", err.message));
      });
    }

    recordingBlobPromise = recordWithMediaRecorder();
  }

  async function onPressEnd() {
    if (el.useBrowserSpeech.checked) {
      if (recognition) recognition.stop();
      el.ptt.classList.remove("recording");
      el.ptt.textContent = "Hold to talk";
      return;
    }
    try {
      const text = await stopRecordingAndTranscribe(recordingBlobPromise);
      if (text) await sendText(text);
    } catch (err) {
      addMessage("assistant", err.message || String(err));
    } finally {
      el.ptt.classList.remove("recording");
      el.ptt.textContent = "Hold to talk";
    }
  }

  el.ptt.addEventListener("pointerdown", () => onPressStart().catch(err => addMessage("assistant", err.message)));
  el.ptt.addEventListener("pointerup", () => onPressEnd().catch(err => addMessage("assistant", err.message)));
  el.ptt.addEventListener("pointerleave", () => {
    if (el.ptt.classList.contains("recording")) onPressEnd().catch(() => {});
  });

  el.sendText.addEventListener("click", () => {
    const v = el.textInput.value;
    el.textInput.value = "";
    sendText(v).catch(err => addMessage("assistant", err.message));
  });
  el.textInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const v = el.textInput.value;
      el.textInput.value = "";
      sendText(v).catch(err => addMessage("assistant", err.message));
    }
  });

  el.stopAudio.addEventListener("click", () => stopPlayback());
  el.resetSession.addEventListener("click", async () => {
    localStorage.removeItem("voice_agent_session");
    sessionId = null;
    await ensureSession(true);
    addMessage("assistant", "New session started. How can I help?");
  });

  // Boot

  // ---- Embed handshake (postMessage) ----
  if (isEmbed && window.parent && window.parent !== window && parentOrigin) {
    window.addEventListener("message", (event) => {
      if (!parentOrigin || event.origin !== parentOrigin) return;
      const data = event.data || {};
      if (data.type === "VOICE_AGENT_CONTEXT") {
        ingestHostContext(data.payload || {}).then(() => {
          try {
            window.parent.postMessage({ type: "VOICE_AGENT_CONTEXT_ACK" }, parentOrigin);
          } catch {}
        });
      }
    });
  }

  ensureSession().then(async () => {
    addMessage("assistant", "Hi. I’m here to help. Hold the button to talk, or type a message.");
    if (isEmbed && window.parent && window.parent !== window && parentOrigin) {
      try {
        window.parent.postMessage({ type: "VOICE_AGENT_READY" }, parentOrigin);
      } catch {}
    }
  });
})();
