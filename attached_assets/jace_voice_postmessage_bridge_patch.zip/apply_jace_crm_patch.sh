#!/usr/bin/env bash
set -euo pipefail

if [ ! -d "client/src" ]; then
  echo "ERROR: Run this from the ROOT of your JACE CRM repo (the folder that contains client/src)." >&2
  exit 1
fi

PATCH_DIR="$(cd "$(dirname "$0")" && pwd)/jace-crm"

copy_one () {
  local src="$1" dst="$2"
  mkdir -p "$(dirname "$dst")"
  cp -v "$src" "$dst"
}

copy_one "$PATCH_DIR/client/src/components/VoiceAssistantWidget.tsx" "client/src/components/VoiceAssistantWidget.tsx"
copy_one "$PATCH_DIR/client/src/pages/external-onboarding.tsx" "client/src/pages/external-onboarding.tsx"

echo "
✅ JACE CRM patch applied."
echo "Next: restart the repl / run the build so Vite recompiles."
