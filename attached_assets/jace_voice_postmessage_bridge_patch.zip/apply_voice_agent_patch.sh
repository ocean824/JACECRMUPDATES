#!/usr/bin/env bash
set -euo pipefail

if [ ! -d "apps/api" ]; then
  echo "ERROR: Run this from the ROOT of your VOICE AGENT repo (the folder that contains apps/api)." >&2
  exit 1
fi

PATCH_DIR="$(cd "$(dirname "$0")" && pwd)/voice-agent"

copy_one () {
  local src="$1" dst="$2"
  mkdir -p "$(dirname "$dst")"
  cp -v "$src" "$dst"
}

copy_one "$PATCH_DIR/apps/api/src/index.ts" "apps/api/src/index.ts"
copy_one "$PATCH_DIR/apps/api/src/routes/voiceAgent.ts" "apps/api/src/routes/voiceAgent.ts"
copy_one "$PATCH_DIR/apps/api/src/voice/db.ts" "apps/api/src/voice/db.ts"
copy_one "$PATCH_DIR/apps/api/src/voice/memory.ts" "apps/api/src/voice/memory.ts"
copy_one "$PATCH_DIR/apps/api/src/voice/llm.ts" "apps/api/src/voice/llm.ts"
copy_one "$PATCH_DIR/apps/api/public/agent.js" "apps/api/public/agent.js"

echo "\n✅ Voice agent patch applied."
echo "Next: restart the repl so TypeScript recompiles."
