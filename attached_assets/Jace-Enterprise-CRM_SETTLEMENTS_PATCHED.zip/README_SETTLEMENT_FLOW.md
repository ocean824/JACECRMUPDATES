# JACE CRM — Settlement Flow (BondAI → JACE)

This repository implements the **full settlement handoff** from **BondAI** to **JACE CRM**, using a **popup/iframe settlement window** and **internal-only escrow confirmation**.

## Goals / Non‑Goals

### ✅ Goals
- BondAI triggers settlement by creating a settlement session in JACE CRM.
- Investor completes a short settlement form inside JACE CRM (popup/iframe).
- JACE internal staff confirm/cancel settlements (no Stripe, no auto-capture).
- **BondAI callback is triggered ONLY after internal confirmation.**
- Settlement receipt PDF generated and attached to the Investor in JACE.
- Audit log entries for submitted/confirmed/cancelled settlement actions.

### ❌ Non‑Goals
- No payment processing in BondAI.
- No Stripe webhooks or auto settlement confirmation.

---

## High-Level Flow

### 1) Investor clicks **“Settle Now”** in BondAI
BondAI calls JACE CRM to create a settlement session:

`POST /api/external/settlement/session`

JACE returns:
- `token` (signed JWT)
- `settlementUrl` = `/settlement?session=<token>`

BondAI opens `settlementUrl` in a **popup** or **iframe**.

### 2) Investor completes settlement request in JACE CRM popup
Investor fills:
- *Payment reference* (wire/ACH reference / confirmation ID / last‑4 / etc.)

Investor submits:

`POST /api/settlement/complete`

Result:
- Settlement session status becomes `submitted`
- **NO BondAI webhook is called yet**

### 3) Internal staff confirms or cancels settlement
Internal roles (admin/accounting/ops/investor_relations) open:

`/settlements`

They see the **Settlement Inbox** (submitted items), and can:
- **Confirm Settlement** → creates receipt PDF + logs audit + triggers BondAI callback
- **Cancel Settlement** → logs audit + no BondAI callback

### 4) BondAI receives confirmation webhook
On **internal confirm only**, JACE CRM sends a signed webhook to BondAI:

`POST {BONDAI_WEBHOOK_URL}`

**Body**
```json
{
  "event": "settlement.completed",
  "timestamp": "2026-02-06T00:00:00.000Z",
  "payload": {
    "tradeId": 123,
    "sessionId": "uuid",
    "investorEmail": "investor@example.com",
    "amount": "2000",
    "paymentReference": "WIRE-ABC-1234",
    "receiptId": "uuid",
    "receiptUrl": "/api/admin/settlements/uuid/receipt"
  }
}
```

**Headers**
- `X-Webhook-Timestamp`: epoch milliseconds (string)
- `X-Webhook-Signature`: HMAC-SHA256 of `${timestamp}.${body}` using `BONDAI_WEBHOOK_SECRET`

---

## Internal UI Behavior

- Internal settlements are accessible at **`/settlements`**.
- The settlement inbox dialog is designed as a **popup**.
- For internal users, the app will automatically route to `/settlements?auto=1` after login **if there are submitted settlements** (one-time per browser session).

---

## API Contract (BondAI Integration)

### 1) Create settlement session (BondAI → JACE)
**Endpoint**

`POST /api/external/settlement/session`

**Headers**
- `X-BondAI-Webhook-Secret: <BONDAI_WEBHOOK_SECRET>` *(or `X-API-Key`)*

**Body**
```json
{
  "tradeId": 123,
  "amount": 2000,
  "bondId": 987,
  "investorId": 456,
  "investorEmail": "investor@example.com",
  "bondName": "Sample Bond Name"
}
```

**Response**
```json
{
  "sessionId": "uuid",
  "token": "<signed_jwt>",
  "settlementUrl": "https://<jace-domain>/settlement?session=<signed_jwt>",
  "createdAt": "2026-02-06T00:00:00.000Z",
  "expiresAt": "2026-02-06T01:00:00.000Z"
}
```

### 2) Load session info (Investor popup → JACE)
`GET /api/settlement/session?token=<signed_jwt>`

### 3) Submit settlement request (Investor popup → JACE)
`POST /api/settlement/complete`

Body:
```json
{
  "token": "<signed_jwt>",
  "paymentReference": "WIRE-ABC-1234"
}
```

### 4) Cancel settlement request (Investor popup → JACE)
`POST /api/settlement/cancel`

Body:
```json
{
  "token": "<signed_jwt>",
  "reason": "Cancelled by investor"
}
```

### 5) Internal settlement inbox (JACE internal UI)
- `GET /api/admin/settlements/summary`
- `GET /api/admin/settlements?status=submitted`
- `POST /api/admin/settlements/:id/confirm` *(triggers BondAI webhook)*
- `POST /api/admin/settlements/:id/cancel`

---

## Environment Variables

### Required
- `DATABASE_URL`
- `BONDAI_WEBHOOK_SECRET` *(shared secret used to validate BondAI → JACE, and to sign JACE → BondAI callbacks)*
- `BONDAI_WEBHOOK_URL` *(where JACE sends settlement confirmation callbacks)*

### Settlement token signing
- `SETTLEMENT_JWT_SECRET` *(preferred)*
  - OR `BONDAI_SETTLEMENT_SECRET` *(fallback)*

### Optional (iframe security)
- `BONDAI_ALLOWED_FRAME_ANCESTORS` (CSP `frame-ancestors` value)
  - Example: `'self' https://your-bond-ai.replit.app`

---

## Database Note (Schema update)
This flow introduces/uses `settlement_sessions.updated_at`.
After pulling this repo, run:

```bash
npm run db:push
```

---

## Files / Entry Points

### Backend
- `server/settlement-routes.ts` — investor + external session endpoints
- `server/settlement-internal-routes.ts` — internal inbox + confirm/cancel + PDF receipt
- `server/services/bondaiSettlementWebhook.ts` — signed callback to BondAI
- `server/lib/pdf/renderSettlementReceiptPdf.tsx` — basic receipt PDF renderer

### Frontend
- `client/src/pages/settlement.tsx` — investor popup settlement UI
- `client/src/pages/settlements.tsx` — internal inbox UI (dialog/popup)
- `client/src/App.tsx` — auto-route to `/settlements?auto=1` on login when submitted settlements exist

