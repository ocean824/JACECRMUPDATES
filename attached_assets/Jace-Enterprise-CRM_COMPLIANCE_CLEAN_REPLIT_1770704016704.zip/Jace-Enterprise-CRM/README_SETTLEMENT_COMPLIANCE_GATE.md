# Settlement Compliance Gate (BondAI → JACE iframe)

This patch adds the **missing compliance gate** required to complete bond assignment settlements initiated in BondAI.

## What changed

### Database

- `settlement_sessions` now includes:
  - `compliance_status`: `not_started | in_progress | complete`
  - `compliance_completed_at`
- New table: `settlement_compliance`
  - Captures entity type (`individual | trust | llc`), legal name
  - Captures SSN/EIN (AES-GCM encrypted + last4)
  - Captures two forms of ID (stored as `documents`)
  - Captures tri-merge credit report (uploaded) OR demo “pull” reference
  - Captures authorization signature and required attestations
  - Produces a PDF compliance packet stored in `documents` (category: `settlement_compliance_gate`)

> **Note:** This repo uses Drizzle `db:push` (no migration folder). Run `npm run db:push` after pulling this patch.

### Server

- New route module: `server/settlement-compliance-routes.ts`
  - `GET  /api/settlement/compliance?token=...` → returns compliance snapshot
  - `POST /api/settlement/compliance/save` → saves partial compliance data
  - `POST /api/settlement/compliance/upload` → uploads `id_primary | id_secondary | credit_report`
  - `POST /api/settlement/compliance/sign` → captures authorization signature
  - `POST /api/settlement/compliance/pull-credit` → demo tri-merge reference
  - `POST /api/settlement/compliance/complete` → validates requirements, marks complete, generates PDF

- Settlement submission is now **gated**:
  - Investor `POST /api/settlement/complete` returns **409** unless `compliance_status = complete`.
  - Internal `POST /api/admin/settlements/:sessionId/confirm` returns **409** unless `compliance_status = complete`.

### Client

- New UI wizard: `client/src/components/SettlementComplianceWizard.tsx`
- `client/src/pages/settlement.tsx` now renders the wizard automatically when `compliance_status !== complete`.
  - The settlement “Submit” button is disabled until compliance completes.
  - On completion, the iframe posts:
    - `JACE_SETTLEMENT_COMPLIANCE_COMPLETED`

## Required compliance data

The compliance wizard enforces:

1. Entity type + legal name
2. SSN/EIN (encrypted)
3. Two forms of ID upload
4. Signed credit authorization + tri-merge (upload or demo pull)
5. Attestations:
   - accredited investor
   - private party purchaser
   - hold harmless
   - EIN/SSN tracking for IRS / “set exchange” recordkeeping

## Environment variables

### Required

- `SETTLEMENT_JWT_SECRET` (or `BONDAI_SETTLEMENT_SECRET`) — JWT verification for iframe sessions
- `BONDAI_ALLOWED_FRAME_ANCESTORS` — CSP `frame-ancestors` for iframe embedding

### Optional

- `JACE_ENCRYPTION_KEY_BASE64` — 32-byte base64 key used to encrypt SSN/EIN (recommended)
  - If not set, a random in-memory key is used (not recommended for production)
- `CREDIT_PROVIDER_MODE=demo|live` — demo mode returns mock tri-merge reference

## Integration notes for BondAI

- **No user login required in JACE.** The entire compliance flow uses the signed settlement JWT.
- Recommended UX in BondAI:
  1. Open the settlement iframe URL.
  2. Listen for `postMessage` events:
     - `JACE_SETTLEMENT_COMPLIANCE_COMPLETED`
     - `JACE_SETTLEMENT_SUBMITTED`
     - `JACE_SETTLEMENT_CANCELLED`
     - `JACE_SETTLEMENT_FAILED`

## Files added/updated

- `shared/schema.ts`
- `server/settlement-compliance-routes.ts`
- `server/lib/pdf/renderSettlementCompliancePdf.tsx`
- `server/settlement-routes.ts` (gating)
- `server/settlement-internal-routes.ts` (gating)
- `server/routes.ts` (register module)
- `client/src/components/SettlementComplianceWizard.tsx`
- `client/src/pages/settlement.tsx`
